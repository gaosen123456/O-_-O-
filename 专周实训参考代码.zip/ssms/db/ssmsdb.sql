/*
 Navicat Premium Data Transfer

 Source Server         : 127.0.0.1
 Source Server Type    : MySQL
 Source Server Version : 80028
 Source Host           : localhost:3306
 Source Schema         : ssmsdb

 Target Server Type    : MySQL
 Target Server Version : 80028
 File Encoding         : 65001

 Date: 25/12/2023 23:36:35
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for clazz
-- ----------------------------
DROP TABLE IF EXISTS `clazz`;
CREATE TABLE `clazz`  (
  `id` int(0) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '班级名称',
  `code` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '班级代码',
  `major` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '专业方向',
  `faculty` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '所属院系',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 9 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '班级' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of clazz
-- ----------------------------
INSERT INTO `clazz` VALUES (1, '22软工1班', '2299701', '软件工程', '软件与人工智能学院');
INSERT INTO `clazz` VALUES (2, '22软工2班', '2299702', '软件工程', '软件与人工智能学院');
INSERT INTO `clazz` VALUES (3, '22软工3班', '2299703', '软件工程', '软件与人工智能学院');
INSERT INTO `clazz` VALUES (4, '22软工4班', '2299704', '软件工程', '软件与人工智能学院');
INSERT INTO `clazz` VALUES (5, '22软工5班', '2299705', '软件工程', '软件与人工智能学院');
INSERT INTO `clazz` VALUES (6, '22软工6班', '2299706', '软件工程', '软件与人工智能学院');
INSERT INTO `clazz` VALUES (7, '22软工7班', '2299707', '软件工程', '软件与人工智能学院');
INSERT INTO `clazz` VALUES (8, '22软工8班', '2299708', '软件工程', '软件与人工智能学院');

-- ----------------------------
-- Table structure for course
-- ----------------------------
DROP TABLE IF EXISTS `course`;
CREATE TABLE `course`  (
  `id` int(0) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '课程名称',
  `code` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '课程代码',
  `credit` int(0) NULL DEFAULT NULL COMMENT '学分',
  `courseType` int(0) NULL DEFAULT NULL COMMENT '课程类型(1-必需 2-选修)',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 12 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '课程' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of course
-- ----------------------------
INSERT INTO `course` VALUES (1, '软件系统分析与设计', '20212530', 3, 1);
INSERT INTO `course` VALUES (2, '软件开发项目实训', '20212592', 2, 1);
INSERT INTO `course` VALUES (3, '面向对象程序设计', '20212514', 4, 1);
INSERT INTO `course` VALUES (4, 'Web程序设计', '20212501', 3, 1);
INSERT INTO `course` VALUES (5, '软件工程导论', '20212588', 2, 1);
INSERT INTO `course` VALUES (6, '软件测试技术', '20212522', 3, 1);
INSERT INTO `course` VALUES (7, '软件质量管理', '20212533', 2, 2);
INSERT INTO `course` VALUES (8, '虚拟现实技术', '20212545', 2, 2);
INSERT INTO `course` VALUES (9, '移动应用开发技术', '20212546', 3, 2);
INSERT INTO `course` VALUES (10, '小程序开发技术', '20212590', 3, 2);
INSERT INTO `course` VALUES (11, '区块链技术', '20212502', 2, 2);


-- ----------------------------
-- Table structure for student
-- ----------------------------
DROP TABLE IF EXISTS `student`;
CREATE TABLE `student`  (
  `id` int(0) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '姓名',
  `gender` varchar(2) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '性别',
  `mobile` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '手机号',
  `studyNum` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '学号',
  `clazzId` int(0) NULL DEFAULT NULL COMMENT '班级Id',
  `userId` int(0) NULL DEFAULT NULL COMMENT '绑定用户Id',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `clazzId`(`clazzId`) USING BTREE,
  INDEX `userId`(`userId`) USING BTREE,
  CONSTRAINT `student_ibfk_1` FOREIGN KEY (`clazzId`) REFERENCES `clazz` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `student_ibfk_2` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 47 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '学生' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of student
-- ----------------------------
INSERT INTO `student` VALUES (1, '张粞敏', '女', '18680813892', '229970440', 8, 4);
INSERT INTO `student` VALUES (2, '周渝', '男', '15922994624', '229970444', 8, 5);
INSERT INTO `student` VALUES (3, '蒋攀', '女', '13068366537', '229970411', 8, 6);
INSERT INTO `student` VALUES (4, '曾小于', '女', '13452955336', '229970436', 8, 7);
INSERT INTO `student` VALUES (5, '江鑫雨', '女', '17383156508', '229970410', 8, 8);
INSERT INTO `student` VALUES (6, '成慧', '女', '17323939985', '229970503', 8, 9);
INSERT INTO `student` VALUES (7, '吴玉婷', '女', '17384728498', '229970426', 8, 10);
INSERT INTO `student` VALUES (8, '唐洁妤', '女', '16623487269', '229970421', 8, 11);
INSERT INTO `student` VALUES (9, '杨银丽', '女', '18883081016', '229970432', 8, 12);
INSERT INTO `student` VALUES (10, '凡文杰', '男', '18315251245', '229970404', 8, 13);
INSERT INTO `student` VALUES (11, '吴广', '男', '16508868252', '229970425', 8, 14);
INSERT INTO `student` VALUES (12, '陈思宇', '男', '18184739065', '229970502', 8, 15);
INSERT INTO `student` VALUES (13, '谌德波', '男', '13696420051', '229970448', 8, 16);
INSERT INTO `student` VALUES (14, '何强', '男', '17823747812', '229970409', 8, 17);
INSERT INTO `student` VALUES (15, '高森', '男', '15823739687', '229970405', 8, 18);
INSERT INTO `student` VALUES (16, '罗昌艳', '女', '15223939249', '229970416', 8, 19);
INSERT INTO `student` VALUES (17, '卢红宇', '女', '15278057196', '229970415', 8, 20);
INSERT INTO `student` VALUES (18, '向黎华', '男', '19115164355', '229970427', 8, 21);
INSERT INTO `student` VALUES (19, '张婧瑶', '女', '13551049883', '229970439', 8, 22);
INSERT INTO `student` VALUES (20, '任秋', '男', '18716909255', '229970420', 8, 23);
INSERT INTO `student` VALUES (21, '陶大为', '男', '18983925210', '229970422', 8, 24);
INSERT INTO `student` VALUES (22, '陈洪平', '男', '18325116512', '229970501', 8, 25);
INSERT INTO `student` VALUES (23, '朱海雪', '女', '15184858585', '229970445', 8, 26);
INSERT INTO `student` VALUES (24, '古琴', '女', '17338373554', '229970406', 8, 27);

-- ----------------------------
-- Table structure for student_course
-- ----------------------------
DROP TABLE IF EXISTS `student_course`;
CREATE TABLE `student_course`  (
  `id` int(0) NOT NULL AUTO_INCREMENT,
  `courseId` int(0) NULL DEFAULT NULL COMMENT '课程Id',
  `teacherId` int(0) NULL DEFAULT NULL COMMENT '教师Id',
  `studentId` int(0) NULL DEFAULT NULL COMMENT '学生Id',
  `term` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '学期名称',
  `inputScoreTime` datetime(0) NULL DEFAULT NULL COMMENT '录入成绩时间',
  `score` double(10, 1) NULL DEFAULT NULL COMMENT '课程成绩',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `courseId`(`courseId`) USING BTREE,
  INDEX `teacherId`(`teacherId`) USING BTREE,
  INDEX `studentId`(`studentId`) USING BTREE,
  CONSTRAINT `student_course_ibfk_1` FOREIGN KEY (`courseId`) REFERENCES `course` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `student_course_ibfk_2` FOREIGN KEY (`teacherId`) REFERENCES `teacher` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `student_course_ibfk_3` FOREIGN KEY (`studentId`) REFERENCES `student` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '选课结果' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of student_course
-- ----------------------------

-- ----------------------------
-- Table structure for teacher
-- ----------------------------
DROP TABLE IF EXISTS `teacher`;
CREATE TABLE `teacher`  (
  `id` int(0) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '姓名',
  `gender` varchar(2) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '性别',
  `mobile` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '手机号',
  `workNum` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '工号',
  `userId` int(0) NULL DEFAULT NULL COMMENT '绑定用户Id',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `userId`(`userId`) USING BTREE,
  CONSTRAINT `teacher_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '教师' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of teacher
-- ----------------------------
INSERT INTO `teacher` VALUES (1, '孔玲', '女', '13609414197', '001', 2);
INSERT INTO `teacher` VALUES (2, '付祥明', '男', '15223025311', '002', 7);

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user`  (
  `id` int(0) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '用户名',
  `account` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '登录账号',
  `password` varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '登录密码',
  `status` int(0) NULL DEFAULT NULL COMMENT '状态(0-正常 1-禁用)',
  `userType` int(0) NULL DEFAULT NULL COMMENT '用户类型(1-系统管理员 2-教师 3-学生)',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 50 CHARACTER SET = utf8 COLLATE = utf8_general_ci COMMENT = '系统用户' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES (1, '系统管理员', 'admin', '123456', 0, 1);
INSERT INTO `user` VALUES (2, '孔玲', 'kl', '123456', 0, 2);
INSERT INTO `user` VALUES (3, '付祥明', 'fxm', '123456', 0, 2);
INSERT INTO `user` VALUES (4, '张粞敏', 'zhangzuomin', '18680813892', 0, 3);
INSERT INTO `user` VALUES (5, '周渝', 'zhouyu', '15922994624', 0, 3);
INSERT INTO `user` VALUES (6, '蒋攀', 'jiangpan', '13068366537', 0, 3);
INSERT INTO `user` VALUES (7, '曾小于', 'zengxiaoyu', '13452955336', 0, 3);
INSERT INTO `user` VALUES (8, '江鑫雨', 'jiangzuoyu', '17383156508', 0, 3);
INSERT INTO `user` VALUES (9, '成慧', 'chenghui', '17323939985', 0, 3);
INSERT INTO `user` VALUES (10, '吴玉婷', 'wuyuzuo', '17384728498', 0, 3);
INSERT INTO `user` VALUES (11, '唐洁妤', 'tangjiezuo', '16623487269', 0, 3);
INSERT INTO `user` VALUES (12, '杨银丽', 'yangyinli', '18883081016', 0, 3);
INSERT INTO `user` VALUES (13, '凡文杰', 'fanwenjie', '18315251245', 0, 3);
INSERT INTO `user` VALUES (14, '吴广', 'wuguang', '16508868252', 0, 3);
INSERT INTO `user` VALUES (15, '陈思宇', 'chensiyu', '18184739065', 0, 3);
INSERT INTO `user` VALUES (16, '谌德波', 'zuodebo', '13696420051', 0, 3);
INSERT INTO `user` VALUES (17, '何强', 'heqiang', '17823747812', 0, 3);
INSERT INTO `user` VALUES (18, '高森', 'gaosen', '15823739687', 0, 3);
INSERT INTO `user` VALUES (19, '罗昌艳', 'luochangyan', '15223939249', 0, 3);
INSERT INTO `user` VALUES (20, '卢红宇', 'luhongyu', '15278057196', 0, 3);
INSERT INTO `user` VALUES (21, '向黎华', 'xianglihua', '19115164355', 0, 3);
INSERT INTO `user` VALUES (22, '张婧瑶', 'zhangzuoyao', '13551049883', 0, 3);
INSERT INTO `user` VALUES (23, '任秋', 'renqiu', '18716909255', 0, 3);
INSERT INTO `user` VALUES (24, '陶大为', 'taodawei', '18983925210', 0, 3);
INSERT INTO `user` VALUES (25, '陈洪平', 'chenhongping', '18325116512', 0, 3);
INSERT INTO `user` VALUES (26, '朱海雪', 'zhuhaixue', '15184858585', 0, 3);
INSERT INTO `user` VALUES (27, '古琴', 'guqin', '17338373554', 0, 3);
INSERT INTO `user` VALUES (28, '赵东颖', 'zhaodongying', '19115189480', 0, 3);
INSERT INTO `user` VALUES (29, '张英杰', 'zhangyingjie', '17783975337', 0, 3);
INSERT INTO `user` VALUES (30, '杨军城', 'yangjuncheng', '15856002361', 0, 3);
INSERT INTO `user` VALUES (31, '危云濠', 'weiyunzuo', '15730888769', 0, 3);
INSERT INTO `user` VALUES (32, '谢浪', 'xielang', '19122697480', 0, 3);
INSERT INTO `user` VALUES (33, '匡钢', 'kuanggang', '17300226189', 0, 3);
INSERT INTO `user` VALUES (34, '谷奇', 'guqi', '13008961932', 0, 3);
INSERT INTO `user` VALUES (35, '邹杰明', 'zoujieming', '15683074683', 0, 3);
INSERT INTO `user` VALUES (36, '袁建鹏', 'yuanjianpeng', '15340586975', 0, 3);
INSERT INTO `user` VALUES (37, '蒋瑞鸿', 'jiangruihong', '13320380286', 0, 3);
INSERT INTO `user` VALUES (38, '庞博仁', 'pangboren', '15878983709', 0, 3);
INSERT INTO `user` VALUES (39, '许俊衡', 'xujunheng', '17784097613', 0, 3);
INSERT INTO `user` VALUES (40, '秦渝', 'qinyu', '18166439385', 0, 3);
INSERT INTO `user` VALUES (41, '丁晓东', 'dingxiaodong', '19936152608', 0, 3);
INSERT INTO `user` VALUES (42, '周涛', 'zhoutao', '18223353720', 0, 3);
INSERT INTO `user` VALUES (43, '袁梓宁', 'yuanzuoning', '15386613289', 0, 3);
INSERT INTO `user` VALUES (44, '左健云', 'zuojianyun', '17823562855', 0, 3);
INSERT INTO `user` VALUES (45, '冉居易', 'ranjuyi', '17265758495', 0, 3);
INSERT INTO `user` VALUES (46, '谢山泉', 'xieshanquan', '19115126459', 0, 3);
INSERT INTO `user` VALUES (47, '赵津念', 'zhaojinnian', '15723428084', 0, 3);
INSERT INTO `user` VALUES (48, '曾晓红', 'zengxiaohong', '15978970207', 0, 3);
INSERT INTO `user` VALUES (49, '曾俊豪', 'zengjunhao', '18996125696', 0, 3);

SET FOREIGN_KEY_CHECKS = 1;
