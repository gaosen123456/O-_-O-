package edu.cqie.ssms.bll;

import java.util.List;

import edu.cqie.ssms.dal.StudentDal;
import edu.cqie.ssms.domain.Student;
import edu.cqie.ssms.ui.FrmLogin;

public class StudentBll {
	StudentDal dal=new StudentDal();
	/**
	 * 新增
	 * 
	 * @param mo
	 * @return
	 */
	public boolean add(Student mo) {
		return dal.add(mo);
	}

	/**
	 * 修改
	 * 
	 * @param mo
	 * @return
	 */
	public boolean update(Student mo) {
		return dal.update(mo);
	}

	/**
	 * 删除
	 * 
	 * @param id
	 * @return
	 */
	public boolean remove(Integer id) {
		return dal.remove(id);
	}

	/**
	 * 根据主键获取实体
	 * 
	 * @param id
	 * @return
	 */
	public Student getById(Integer id) {
		return dal.getById(id);
	}

	/**
	 * 根据主键范围获取实体集
	 * 
	 * @param ids
	 * @return
	 */
	public List<Student> getByIds(List<Integer> ids) {
		return dal.getByIds(ids);
	}

	/**
	 * 获取全部实体
	 * 
	 * @return
	 */
	public List<Student> getAll() {
		return dal.getAll();
	}
	/**
	 * Id-->Name
	 * 
	 * @param id
	 * @param all
	 * @return
	 */
	public String mapNameById(Integer id, List<Student> all) {
		if(id==null||all==null||all.size()==0) {
			return "";
		}
		Student find=all.stream().filter(x->x.getId()==id).findFirst().orElse(null);
		if(find==null) {
			return "";
		}
		return find.getName();
	}
	/**
	 * 确定登录学生
	 * userId-->Student
	 * 
	 * @param userId
	 * @return
	 */
	public Student mapUserIdStudent(Integer userId) {
		return dal.mapUserIdStudent(userId);
	}

	public static void main(String[] args) {
		StudentBll bll=new StudentBll();
		List<Student> all=bll.getAll();
		for(Student item : all) {
			System.out.println(item.getName());
		}
	}	
}
