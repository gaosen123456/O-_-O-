package edu.cqie.ssms.bll;

import java.util.ArrayList;
import java.util.List;

import edu.cqie.ssms.dal.TeacherDal;
import edu.cqie.ssms.domain.SelectListItem;
import edu.cqie.ssms.domain.Teacher;

public class TeacherBll {
	TeacherDal dal=new TeacherDal();
	/**
	 * 新增
	 * 
	 * @param mo
	 * @return
	 */
	public boolean add(Teacher mo) {
		return dal.add(mo);
	}

	/**
	 * 修改
	 * 
	 * @param mo
	 * @return
	 */
	public boolean update(Teacher mo) {
		return dal.update(mo);
	}

	/**
	 * 删除
	 * 
	 * @param id
	 * @return
	 */
	public boolean remove(Integer id) {
		return dal.remove(id);
	}

	/**
	 * 根据主键获取实体
	 * 
	 * @param id
	 * @return
	 */
	public Teacher getById(Integer id) {
		return dal.getById(id);
	}

	/**
	 * 根据主键范围获取实体集
	 * 
	 * @param ids
	 * @return
	 */
	public List<Teacher> getByIds(List<Integer> ids) {
		return dal.getByIds(ids);
	}

	/**
	 * 获取全部实体
	 * 
	 * @return
	 */
	public List<Teacher> getAll() {
		return dal.getAll();
	}

	/**
	 * Id-->Name
	 * 
	 * @param id
	 * @param all
	 * @return
	 */
	public String mapNameById(Integer id, List<Teacher> all) {
		if (id == null || all == null || all.size() == 0) {
			return "";
		}
		Teacher find = all.stream().filter(x -> x.getId() == id).findFirst().orElse(null);
		if (find == null) {
			return "";
		}
		return find.getName();
	}

	/**
	 * 选择教师的备选项
	 * 
	 * @return
	 */
	public List<SelectListItem> getOptions() {
		List<SelectListItem> ret = new ArrayList<>();
		List<Teacher> all = dal.getAll();
		for (Teacher item : all) {
			SelectListItem sli = new SelectListItem();
			sli.setText(item.getName());
			sli.setValue(item.getId() + "");

			ret.add(sli);
		}
		return ret;
	}
	/**
	 * 确定登录教师
	 * 
	 * userId-->Teacher
	 * @param userId
	 * @return
	 */
	public Teacher mapUserIdTeacher(Integer userId) {
		return dal.mapUserIdTeacher(userId);
	}
}
