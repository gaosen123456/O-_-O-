package edu.cqie.ssms.bll;

import java.util.ArrayList;
import java.util.List;

import edu.cqie.ssms.dal.CourseDal;
import edu.cqie.ssms.domain.Course;
import edu.cqie.ssms.domain.SelectListItem;

public class CourseBll {
	CourseDal dal=new CourseDal();
	/**
	 * 新增
	 * 
	 * @param mo
	 * @return
	 */
	public boolean add(Course mo) {
		return dal.add(mo);
	}

	/**
	 * 修改
	 * 
	 * @param mo
	 * @return
	 */
	public boolean update(Course mo) {
		return dal.update(mo);
	}

	/**
	 * 删除
	 * 
	 * @param id
	 * @return
	 */
	public boolean remove(Integer id) {
		return dal.remove(id);
	}

	/**
	 * 根据主键获取实体
	 * 
	 * @param id
	 * @return
	 */
	public Course getById(Integer id) {
		return dal.getById(id);
	}

	/**
	 * 根据主键范围获取实体集
	 * 
	 * @param ids
	 * @return
	 */
	public List<Course> getByIds(List<Integer> ids) {
		return dal.getByIds(ids);
	}

	/**
	 * 获取全部实体
	 * 
	 * @return
	 */
	public List<Course> getAll() {
		return dal.getAll();
	}

	/**
	 * Id-->Name
	 * 
	 * @param id
	 * @param all 查找范围
	 * @return
	 */
	public String mapNameById(Integer id, List<Course> all) {
		if (id == null || all == null || all.size() == 0) {
			return "";
		}
		Course find = all.stream().filter(x -> x.getId() == id).findFirst().orElse(null);
		if (find == null) {
			return "";
		}
		return find.getName();
	}
	
	/**
	 * 选择班级的备选项
	 * 
	 * @return
	 */
	public List<SelectListItem> getOptions() {
		List<SelectListItem> ret=new ArrayList<>();
		List<Course> all=dal.getAll();
		for(Course item:all) {
			SelectListItem sli=new SelectListItem();
			sli.setText(String.format("[%s]%s", item.getCode(),item.getName()));
			sli.setValue(item.getId()+"");
			
			ret.add(sli);
		}
		return ret;
	}
	/**
	 * courseType-->name
	 * 
	 * @param courseType
	 * @return
	 */
	public String mapNameByCourseType(Integer courseType) {
		if(courseType==null) {
			return "";
		}
		if(courseType==1) {
			return "必修";
		}
		if(courseType==2) {
			return "选修";
		}
		return "错误的课程类型值";
	}
}
