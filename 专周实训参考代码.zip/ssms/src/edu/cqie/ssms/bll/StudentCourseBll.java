package edu.cqie.ssms.bll;

import java.util.List;

import edu.cqie.ssms.dal.StudentCourseDal;
import edu.cqie.ssms.domain.StudentCourse;

public class StudentCourseBll {
	StudentCourseDal dal=new StudentCourseDal();
	/**
	 * 新增
	 * 
	 * @param mo
	 * @return
	 */
	public boolean add(StudentCourse mo) {
		return dal.add(mo);
	}

	/**
	 * 修改
	 * 
	 * @param mo
	 * @return
	 */
	public boolean update(StudentCourse mo) {
		return dal.update(mo);
	}

	/**
	 * 删除
	 * 
	 * @param id
	 * @return
	 */
	public boolean remove(Integer id) {
		return dal.remove(id);
	}

	/**
	 * 根据主键获取实体
	 * 
	 * @param id
	 * @return
	 */
	public StudentCourse getById(Integer id) {
		return dal.getById(id);
	}

	/**
	 * 获取全部实体
	 * 
	 * @return
	 */
	public List<StudentCourse> getAll() {
		return dal.getAll();
	}

	/**
	 * 根据学生Id获取列表
	 * 
	 * @param studentId
	 * @return
	 */
	public List<StudentCourse> getListByStudentId(Integer studentId) {
		return dal.getListByStudentId(studentId);
	}
}
