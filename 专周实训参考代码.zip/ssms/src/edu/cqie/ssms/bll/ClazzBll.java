package edu.cqie.ssms.bll;

import java.util.List;

import edu.cqie.ssms.dal.ClazzDal;
import edu.cqie.ssms.domain.Clazz;

public class ClazzBll {
	ClazzDal dal=new ClazzDal();
	/**
	 * 新增
	 * 
	 * @param mo
	 * @return
	 */
	public boolean add(Clazz mo) {
		return dal.add(mo);
	}

	/**
	 * 修改
	 * 
	 * @param mo
	 * @return
	 */
	public boolean update(Clazz mo) {
		return dal.update(mo);
	}

	/**
	 * 删除
	 * 
	 * @param id
	 * @return
	 */
	public boolean remove(Integer id) {
		return dal.remove(id);
	}

	/**
	 * 根据主键获取实体
	 * 
	 * @param id
	 * @return
	 */
	public Clazz getById(Integer id) {
		return dal.getById(id);
	}

	/**
	 * 根据Id范围获取实体集
	 * 
	 * @param ids
	 * @return
	 */
	public List<Clazz> getByIds(List<Integer> ids) {
		return dal.getByIds(ids);
	}

	/**
	 * 获取全部实体
	 * 
	 * @return
	 */
	public List<Clazz> getAll() {
		return dal.getAll();
	}
}
