package edu.cqie.ssms.bll;

import java.util.List;

import edu.cqie.ssms.dal.UserDal;
import edu.cqie.ssms.domain.User;

public class UserBll {
	UserDal dal=new UserDal();
	/**
	 * 新增
	 * 
	 * @param mo
	 * @return
	 */
	public boolean add(User mo) {
		return dal.add(mo);
	}

	/**
	 * 修改
	 * 
	 * @param mo
	 * @return
	 */
	public boolean update(User mo) {
		return dal.update(mo);
	}

	/**
	 * 删除
	 * 
	 * @param id
	 * @return
	 */
	public boolean remove(Integer id) {
		return dal.remove(id);
	}

	/**
	 * 根据主键获取实体
	 * 
	 * @param id
	 * @return
	 */
	public User getById(Integer id) {
		return dal.getById(id);
	}

	/**
	 * 根据Id范围获取实体集
	 * 
	 * @param ids
	 * @return
	 */
	public List<User> getByIds(List<Integer> ids) {
		return dal.getByIds(ids);
	}

	/**
	 * 获取全部实体
	 * 
	 * @return
	 */
	public List<User> getAll() {
		return dal.getAll();
	}

	/**
	 * 获取分配学生账号时可用的用户
	 * 
	 * @param studentId
	 * @return
	 */
	public List<User> getStudentUser(Integer studentId) {
		return dal.getStudentUser(studentId);
	}

	/**
	 * 获取分配教师账号时可用的用户
	 * 
	 * @param teacherId
	 * @return
	 */
	public List<User> getTeacherUser(Integer teacherId) {
		return dal.getTeacherUser(teacherId);
	}

	/**
	 * 登录验证
	 * 
	 * @param account
	 * @param password
	 * @return
	 */
	public User getLoginUser(String account, String password) {
		return dal.getLoginUser(account,password);
	}

	/**
	 * id-->account
	 * 
	 * @param userId
	 * @param all 查询范围
	 * @return
	 */
	public String getUserAccountNameById(Integer userId, List<User> all) {
		if (userId == null || all == null || all.size() == 0) {
			return "";
		}
		User user = all.stream().filter(x -> x.getId().equals(userId)).findFirst().orElse(null);
		if (user == null) {
			return "";
		}
		return user.getAccount();
	}
}
