package edu.cqie.ssms.domain;

/**
 * 实体类: 班级
 * 
 * @author 付祥明
 *
 */
public class Clazz {
	/**
	 * 主键
	 */
	private Integer id;
	/**
	 * 班级名称
	 */
	private String name;
	/**
	 * 班级代码
	 */
	private String code;
	/**
	 * 专业方向
	 */
	private String major;
	/**
	 * 所属院系
	 */
	private String faculty;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getMajor() {
		return major;
	}

	public void setMajor(String major) {
		this.major = major;
	}

	public String getFaculty() {
		return faculty;
	}

	public void setFaculty(String faculty) {
		this.faculty = faculty;
	}

}
