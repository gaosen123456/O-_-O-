package edu.cqie.ssms.domain;

import java.time.LocalDateTime;

/**
 * 实体类: 学生选课结果及成绩
 * 
 * @author 付祥明
 *
 */
public class StudentCourse {
	/**
	 * 主键
	 */
	private Integer id;
	/**
	 * 课程Id
	 */
	private Integer courseId;
	/**
	 * 教师Id
	 */
	private Integer teacherId;
	/**
	 * 学生Id
	 */
	private Integer studentId;
	/**
	 * 学期
	 */
	private String term;
	/**
	 * 录入成绩时间
	 */
	private LocalDateTime inputScoreTime;
	/**
	 * 成绩
	 */
	private Double score;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getCourseId() {
		return courseId;
	}

	public void setCourseId(Integer courseId) {
		this.courseId = courseId;
	}

	public Integer getTeacherId() {
		return teacherId;
	}

	public void setTeacherId(Integer teacherId) {
		this.teacherId = teacherId;
	}

	public Integer getStudentId() {
		return studentId;
	}

	public void setStudentId(Integer studentId) {
		this.studentId = studentId;
	}

	public String getTerm() {
		return term;
	}

	public void setTerm(String term) {
		this.term = term;
	}

	public LocalDateTime getInputScoreTime() {
		return inputScoreTime;
	}

	public void setInputScoreTime(LocalDateTime inputScoreTime) {
		this.inputScoreTime = inputScoreTime;
	}

	public Double getScore() {
		return score;
	}

	public void setScore(Double score) {
		this.score = score;
	}

}
