package edu.cqie.ssms.domain;

/**
 * 实体类: 课程
 * 
 * @author 付祥明
 *
 */
public class Course {
	/**
	 * 主键
	 */
	private Integer id;
	/**
	 * 课程名称
	 */
	private String name;
	/**
	 * 课程代码
	 */
	private String code;
	/**
	 * 学分
	 */
	private Integer credit;
	/**
	 * 课程类型
	 * 1-必需
	 * 2-选修
	 */
	private Integer courseType;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public Integer getCredit() {
		return credit;
	}

	public void setCredit(Integer credit) {
		this.credit = credit;
	}

	public Integer getCourseType() {
		return courseType;
	}

	public void setCourseType(Integer courseType) {
		this.courseType = courseType;
	}

}
