package edu.cqie.ssms.domain;
/**
 * 通用扩展类:备选项
 * 适用于单选、多选
 * 
 * @author 付祥明
 *
 */
public class SelectListItem {
	/**
	 * 值
	 */
	private String value;
	/**
	 * 文本
	 */
	private String text;

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}
}
