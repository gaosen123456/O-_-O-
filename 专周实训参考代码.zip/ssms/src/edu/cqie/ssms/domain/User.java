package edu.cqie.ssms.domain;

/**
 * 实体类: 用户
 * 
 * @author 付祥明
 *
 */
public class User {
	/**
	 * 主键
	 */
	private Integer id;
	/**
	 * 用户名
	 */
	private String name;
	/**
	 * 登录账号
	 */
	private String account;
	/**
	 * 登录密码
	 */
	private String password;
	/**
	 * 用户类型
	 * 1-系统管理员 
	 * 2-教师 
	 * 3-学生
	 */
	private Integer userType;
	/**
	 * 状态
	 * 0-正常 
	 * 1-禁用
	 */
	private Integer status;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Integer getUserType() {
		return userType;
	}

	public void setUserType(Integer userType) {
		this.userType = userType;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}
}
