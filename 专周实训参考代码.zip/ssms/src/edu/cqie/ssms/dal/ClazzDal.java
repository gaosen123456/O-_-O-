package edu.cqie.ssms.dal;

import java.util.List;
import edu.cqie.ssms.domain.Clazz;

public class ClazzDal {
	/**
	 * 新增
	 * 
	 * @param mo
	 * @return
	 */
	public boolean add(Clazz mo) {
		String sql = "insert into clazz(name,code,major,faculty)values(?,?,?,?);";

		return JdbcUtil.excuteSql(sql, mo.getName(), mo.getCode(), mo.getMajor(), mo.getFaculty());
	}

	/**
	 * 修改
	 * 
	 * @param mo
	 * @return
	 */
	public boolean update(Clazz mo) {
		String sql = "update clazz set name=?,code=?,major=?,faculty=? where id=?;";

		return JdbcUtil.excuteSql(sql, mo.getName(), mo.getCode(), mo.getMajor(), mo.getFaculty(), mo.getId());
	}

	/**
	 * 删除
	 * 
	 * @param id
	 * @return
	 */
	public boolean remove(Integer id) {
		String sql = "delete from clazz where id=?;";

		return JdbcUtil.excuteSql(sql, id);
	}

	/**
	 * 根据主键获取实体
	 * 
	 * @param id
	 * @return
	 */
	public Clazz getById(Integer id) {
		String sql = "select * from clazz where id=?;";

		return JdbcUtil.getOne(Clazz.class, sql, id);
	}

	/**
	 * 根据Id范围获取实体集
	 * 
	 * @param ids
	 * @return
	 */
	public List<Clazz> getByIds(List<Integer> ids) {
		StringBuffer sb = new StringBuffer();
		for (Integer id : ids) {
			sb.append(id).append(",");
		}
		sb.delete(sb.length() - 1, sb.length());
		String sql = "select * from clazz where id in(" + sb.toString() + ");";
		return JdbcUtil.list(Clazz.class, sql);
	}

	/**
	 * 获取全部实体
	 * 
	 * @return
	 */
	public List<Clazz> getAll() {
		String sql = "select * from clazz;";

		return JdbcUtil.list(Clazz.class, sql);
	}
}
