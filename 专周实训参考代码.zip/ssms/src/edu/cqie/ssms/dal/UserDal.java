package edu.cqie.ssms.dal;

import java.util.List;
import edu.cqie.ssms.domain.User;

public class UserDal {

	/**
	 * 新增
	 * 
	 * @param mo
	 * @return
	 */
	public boolean add(User mo) {
		String sql = "insert into user(name,account,password,userType,status)values(?,?,?,?,?);";

		return JdbcUtil.excuteSql(sql, mo.getName(), mo.getAccount(), mo.getPassword(), mo.getUserType(),
				mo.getStatus());
	}

	/**
	 * 修改
	 * 
	 * @param mo
	 * @return
	 */
	public boolean update(User mo) {
		String sql = "update user set name=?,account=?,password=?,userType=?,status=? where id=?;";

		return JdbcUtil.excuteSql(sql, mo.getName(), mo.getAccount(), mo.getPassword(), mo.getUserType(),
				mo.getStatus(), mo.getId());
	}

	/**
	 * 删除
	 * 
	 * @param id
	 * @return
	 */
	public boolean remove(Integer id) {
		String sql = "delete from user where id=?;";

		return JdbcUtil.excuteSql(sql, id);
	}

	/**
	 * 根据主键获取实体
	 * 
	 * @param id
	 * @return
	 */
	public User getById(Integer id) {
		String sql = "select * from user where id=?;";

		return JdbcUtil.getOne(User.class, sql, id);
	}

	/**
	 * 根据Id范围获取实体集
	 * 
	 * @param ids
	 * @return
	 */
	public List<User> getByIds(List<Integer> ids) {
		StringBuffer sb = new StringBuffer();
		for (Integer id : ids) {
			sb.append(id).append(",");
		}
		sb.delete(sb.length() - 1, sb.length());
		String sql = "select * from user where id in(" + sb.toString() + ");";
		return JdbcUtil.list(User.class, sql);
	}

	/**
	 * 获取全部实体
	 * 
	 * @return
	 */
	public List<User> getAll() {
		String sql = "select * from user;";

		return JdbcUtil.list(User.class, sql);
	}

	/**
	 * 获取分配学生账号时可用的用户
	 * 
	 * @param studentId
	 * @return
	 */
	public List<User> getStudentUser(Integer studentId) {
		String sql = "select * from user where id not in(select userId from teacher where userId is not null) and id not in(select userId from student where userId is not null and id<>?);";

		return JdbcUtil.list(User.class, sql, studentId);
	}

	/**
	 * 获取分配教师账号时可用的用户
	 * 
	 * @param teacherId
	 * @return
	 */
	public List<User> getTeacherUser(Integer teacherId) {
		String sql = "select * from user where id not in(select userId from teacher where userId is not null  and id<>?) and id not in(select userId from student where userId is not null);";

		return JdbcUtil.list(User.class, sql, teacherId);
	}

	/**
	 * 登录验证
	 * 
	 * @param account
	 * @param password
	 * @return
	 */
	public User getLoginUser(String account, String password) {
		String sql = "select * from user where account=? and password=?;";

		return JdbcUtil.getOne(User.class, sql, account, password);
	}
}
