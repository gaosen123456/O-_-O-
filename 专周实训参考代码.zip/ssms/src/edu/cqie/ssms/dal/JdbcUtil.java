package edu.cqie.ssms.dal;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * 通用工具类：JDBC访问MySql数据库
 * 
 * @author 付祥明
 *
 */
public class JdbcUtil {
	// 数据库的用户名
	private final static String USERNAME = "root";
	// 数据库的密码
	private final static String PASSWORD = "root";
	// 数据库的驱动信息
	private final static String DRIVER = "com.mysql.cj.jdbc.Driver";
	// 数据库的地址
	private final static String URL = "jdbc:mysql://localhost/ssmsdb?useUnicode=true&characterEncoding=utf-8";

	/**
	 * 获取数据库连接
	 * 
	 * @return
	 */
	private static Connection getConnection() {
		Connection conn = null;
		try {
			// 加载驱动
			Class.forName(DRIVER);
			// 连接数据库
			conn = java.sql.DriverManager.getConnection(URL, USERNAME, PASSWORD);
			System.out.println("连接数据库......ok");

		} catch (Exception e) {
			e.printStackTrace();
		}
		return conn;
	}

	/**
	 * 执行增加、删除、修改的SQL
	 * 
	 * @param sql
	 * @param objects
	 * @return
	 */
	public static boolean excuteSql(String sql, Object... objects) {
		Connection conn = null;
		PreparedStatement ps = null;
		try {
			// 1.建立连接
			conn = getConnection();
			// 2.准备需执行的sql
			ps = conn.prepareStatement(sql);
			// 3.注入参数
			if (objects != null) {
				for (int i = 0; i < objects.length; i++) {
					ps.setObject(i + 1, objects[i]);
				}
			}
			// 4.执行sql
			System.out.println(ps.toString());
			int result = ps.executeUpdate();
			System.out.println(result);
			// 5.返回值
			return (result > 0);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// 释放资源
			try {
				if (ps != null) {
					ps.close();
				}
			} catch (SQLException e2) {
				e2.printStackTrace();
			}

			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		}
		return false;
	}

	/**
	 * 查询返回单条记录
	 * 
	 * @param cls
	 * @param sql
	 * @param objects
	 * @return
	 */
	public static <T> T getOne(Class<T> cls, String sql, Object... objects) {
		T resultObject = null;
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			// 1.连接数据库
			conn = getConnection();
			// 2.准备需执行的sql
			ps = conn.prepareStatement(sql);
			// 参数注入
			if (objects != null) {
				for (int i = 0; i < objects.length; i++) {
					ps.setObject(i + 1, objects[i]);
				}
			}
			// 3.执行查询
			System.out.println(ps.toString());// 输出sql
			rs = ps.executeQuery();

			// 4.准备返回值
			// 获取列的信息
			ResultSetMetaData metaData = (ResultSetMetaData) rs.getMetaData();
			// 列数
			int columnCount = metaData.getColumnCount();
			while (rs.next()) {
				// 通过反射机制创建实例
				resultObject = cls.newInstance();
				for (int i = 0; i < columnCount; i++) {
					// 属性名
					String fieldName = metaData.getColumnName(i + 1);
					// 属性值
					Object fieldValue = rs.getObject(fieldName);
					// 属性名-->实体类的属性
					java.lang.reflect.Field field = cls.getDeclaredField(fieldName);
					// 打开属性访问权限
					field.setAccessible(true);
					// 对属性赋值
					field.set(resultObject, fieldValue);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// 释放rs
			if (rs != null) {
				try {
					rs.close();
				} catch (Exception e3) {
					e3.printStackTrace();
				}
			}
			// 释放ps
			if (ps != null) {
				try {
					ps.close();
				} catch (Exception e2) {
					e2.printStackTrace();
				}
			}
			// 释放conn
			if (conn != null) {
				try {
					conn.close();
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
		}
		return resultObject;
	}

	/**
	 * 查询返回多条记录
	 * 
	 * @param cls
	 * @param sql
	 * @param objects
	 * @return
	 */
	public static <T> List<T> list(Class<T> cls, String sql, Object... objects) {
		List<T> list = new ArrayList<T>();
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			// 1.连接数据库
			conn = getConnection();
			// 2.准备需执行的sql
			ps = conn.prepareStatement(sql);
			// 参数注入
			if (objects != null) {
				for (int i = 0; i < objects.length; i++) {
					ps.setObject(i + 1, objects[i]);
				}
			}
			// 3.执行查询
			System.out.println(ps.toString());// 输出sql
			rs = ps.executeQuery();

			// 4.准备返回值
			// 获取列的信息
			ResultSetMetaData metaData = (ResultSetMetaData) rs.getMetaData();
			// 列数
			int columnCount = metaData.getColumnCount();
			while (rs.next()) {
				// 通过反射机制创建实例
				T resultObject = cls.newInstance();
				for (int i = 0; i < columnCount; i++) {
					// 属性名
					String fieldName = metaData.getColumnName(i + 1);
					// 属性值
					Object fieldValue = rs.getObject(fieldName);
					// 属性名-->实体的属性
					java.lang.reflect.Field field = cls.getDeclaredField(fieldName);
					// 打开属性访问权限
					field.setAccessible(true);
					// 对属性赋值
					field.set(resultObject, fieldValue);
				}
				list.add(resultObject);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// 释放rs
			if (rs != null) {
				try {
					rs.close();
				} catch (Exception e3) {
					e3.printStackTrace();
				}
			}
			// 释放ps
			if (ps != null) {
				try {
					ps.close();
				} catch (Exception e2) {
					e2.printStackTrace();
				}
			}
			// 释放conn
			if (conn != null) {
				try {
					conn.close();
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
		}

		return list;
	}
}
