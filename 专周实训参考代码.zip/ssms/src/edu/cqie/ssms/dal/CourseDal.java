package edu.cqie.ssms.dal;

import java.util.List;

import edu.cqie.ssms.domain.Course;

public class CourseDal {
	/**
	 * 新增 
	 * 
	 * @param mo
	 * @return
	 */
	public boolean add(Course mo) {
		String sql = "insert into course(name,code,credit,courseType)values(?,?,?,?);";

		return JdbcUtil.excuteSql(sql, mo.getName(), mo.getCode(), mo.getCredit(), mo.getCourseType());
	}

	/**
	 * 修改
	 * 
	 * @param mo
	 * @return
	 */
	public boolean update(Course mo) {
		String sql = "update course set name=?,code=?,credit=?,courseType=? where id=?;";

		return JdbcUtil.excuteSql(sql, mo.getName(), mo.getCode(), mo.getCredit(), mo.getCourseType(), mo.getId());
	}

	/**
	 * 删除
	 * 
	 * @param id
	 * @return
	 */
	public boolean remove(Integer id) {
		String sql = "delete from course where id=?;";

		return JdbcUtil.excuteSql(sql, id);
	}

	/**
	 * 根据主键获取实体
	 * 
	 * @param id
	 * @return
	 */
	public Course getById(Integer id) {
		String sql = "select * from course where id=?;";

		return JdbcUtil.getOne(Course.class, sql, id);
	}

	/**
	 * 根据主键范围获取实体集
	 * 
	 * @param ids
	 * @return
	 */
	public List<Course> getByIds(List<Integer> ids) {
		StringBuffer sb = new StringBuffer();
		for (Integer id : ids) {
			sb.append(id).append(",");
		}
		sb.delete(sb.length() - 1, sb.length());
		String sql = "select * from course where id in(" + sb.toString() + ");";

		return JdbcUtil.list(Course.class, sql);
	}

	/**
	 * 获取全部实体
	 * 
	 * @return
	 */
	public List<Course> getAll() {
		String sql = "select * from course;";

		return JdbcUtil.list(Course.class, sql);
	}
}
