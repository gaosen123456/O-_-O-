package edu.cqie.ssms.dal;

import java.util.List;

import edu.cqie.ssms.domain.StudentCourse;

public class StudentCourseDal {
	/**
	 * 新增
	 * 
	 * @param mo
	 * @return
	 */
	public boolean add(StudentCourse mo) {
		String sql = "insert into student_course(courseId,teacherId,studentId,term,inputScoreTime,score)values(?,?,?,?,?,?);";

		return JdbcUtil.excuteSql(sql, mo.getCourseId(), mo.getTeacherId(), mo.getStudentId(), mo.getTerm(),
				mo.getInputScoreTime(), mo.getScore());
	}

	/**
	 * 修改
	 * 
	 * @param mo
	 * @return
	 */
	public boolean update(StudentCourse mo) {
		String sql = "update student_course set courseId=?,teacherId=?,studentId=?,term=?,inputScoreTime=?,score=? where id=?;";

		return JdbcUtil.excuteSql(sql, mo.getCourseId(), mo.getTeacherId(), mo.getStudentId(), mo.getTerm(),
				mo.getInputScoreTime(), mo.getScore(), mo.getId());
	}

	/**
	 * 删除
	 * 
	 * @param id
	 * @return
	 */
	public boolean remove(Integer id) {
		String sql = "delete from student_course where id=?;";

		return JdbcUtil.excuteSql(sql, id);
	}

	/**
	 * 根据主键获取实体
	 * 
	 * @param id
	 * @return
	 */
	public StudentCourse getById(Integer id) {
		String sql = "select * from student_course where id=?;";

		return JdbcUtil.getOne(StudentCourse.class, sql, id);
	}

	/**
	 * 获取全部实体
	 * 
	 * @return
	 */
	public List<StudentCourse> getAll() {
		String sql = "select * from student_course;";

		return JdbcUtil.list(StudentCourse.class, sql);
	}

	/**
	 * 根据学生Id获取列表
	 * 
	 * @param studentId
	 * @return
	 */
	public List<StudentCourse> getListByStudentId(Integer studentId) {
		String sql = "select * from student_course where score is not null and studentId=?;";

		return JdbcUtil.list(StudentCourse.class, sql, studentId);
	}
}
