package edu.cqie.ssms.dal;

import java.util.List;

import edu.cqie.ssms.domain.Teacher;

public class TeacherDal {
	/**
	 * 新增
	 * 
	 * @param mo
	 * @return
	 */
	public boolean add(Teacher mo) {
		String sql = "insert into teacher(name,gender,mobile,workNum,userId)values(?,?,?,?,?);";

		return JdbcUtil.excuteSql(sql, mo.getName(), mo.getGender(), mo.getMobile(), mo.getWorkNum(), mo.getUserId());
	}

	/**
	 * 修改
	 * 
	 * @param mo
	 * @return
	 */
	public boolean update(Teacher mo) {
		String sql = "update teacher set name=?,gender=?,mobile=?,workNum=?,userId=? where id=?;";

		return JdbcUtil.excuteSql(sql, mo.getName(), mo.getGender(), mo.getMobile(), mo.getWorkNum(), mo.getUserId(),
				mo.getId());
	}

	/**
	 * 删除
	 * 
	 * @param id
	 * @return
	 */
	public boolean remove(Integer id) {
		String sql = "delete from teacher where id=?;";

		return JdbcUtil.excuteSql(sql, id);
	}

	/**
	 * 根据主键获取实体
	 * 
	 * @param id
	 * @return
	 */
	public Teacher getById(Integer id) {
		String sql = "select * from teacher where id=?;";

		return JdbcUtil.getOne(Teacher.class, sql, id);
	}

	/**
	 * 根据主键范围获取实体集
	 * 
	 * @param ids
	 * @return
	 */
	public List<Teacher> getByIds(List<Integer> ids) {
		StringBuffer sb = new StringBuffer();
		for (Integer id : ids) {
			sb.append(id).append(",");
		}
		sb.delete(sb.length() - 1, sb.length());
		String sql = "select * from teacher where id in(" + sb.toString() + ");";

		return JdbcUtil.list(Teacher.class, sql);
	}

	/**
	 * 获取全部实体
	 * 
	 * @return
	 */
	public List<Teacher> getAll() {
		String sql = "select * from teacher;";

		return JdbcUtil.list(Teacher.class, sql);
	}

	/**
	 * 获取登录教师
	 * userId-->Teacher
	 * 
	 * @param userId
	 * @return
	 */
	public Teacher mapUserIdTeacher(Integer userId) {
		String sql = "select * from teacher where userId=?;";

		return JdbcUtil.getOne(Teacher.class, sql,userId);
	}
}
