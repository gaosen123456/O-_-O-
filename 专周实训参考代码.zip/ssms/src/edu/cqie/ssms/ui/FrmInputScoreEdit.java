package edu.cqie.ssms.ui;

import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDateTime;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import edu.cqie.ssms.bll.CourseBll;
import edu.cqie.ssms.bll.StudentBll;
import edu.cqie.ssms.bll.StudentCourseBll;
import edu.cqie.ssms.domain.StudentCourse;

@SuppressWarnings("serial")
public class FrmInputScoreEdit extends JDialog {
	Integer id;
	FrmInputScoreList owner;
	StudentCourseBll studentCourseBll = new StudentCourseBll();

	public FrmInputScoreEdit(FrmInputScoreList owner, Integer id) {
		this.setModal(true);
		this.id = id;
		this.owner = owner;
		InitializeComponent();
	}

	private void InitializeComponent() {
		// 1.窗体
		this.setTitle("录入课程成绩");
		this.setLayout(null);
		this.setLocationRelativeTo(null);
		this.setResizable(false);
		this.setSize(380, 200);

		JLabel lblTerm = new JLabel("学期:");
		lblTerm.setBounds(40, 10, 100, 20);
		this.getContentPane().add(lblTerm);
		TextField txtTerm = new TextField();
		txtTerm.setBounds(150, 10, 140, 20);
		txtTerm.setEditable(false);
		this.getContentPane().add(txtTerm);

		JLabel lblStudentName = new JLabel("学生姓名:");
		lblStudentName.setBounds(40, 40, 100, 20);
		this.getContentPane().add(lblStudentName);
		TextField txtStudentName = new TextField();
		txtStudentName.setBounds(150, 40, 140, 20);
		txtStudentName.setEditable(false);
		this.getContentPane().add(txtStudentName);

		JLabel lblCourseName = new JLabel("课程名称:");
		lblCourseName.setBounds(40, 70, 100, 20);
		this.getContentPane().add(lblCourseName);
		TextField txtCourseName = new TextField();
		txtCourseName.setBounds(150, 70, 140, 20);
		txtCourseName.setEditable(false);
		this.getContentPane().add(txtCourseName);

		JLabel lblScore = new JLabel("成绩:");
		lblScore.setBounds(40, 100, 100, 20);
		this.getContentPane().add(lblScore);
		TextField txtScore = new TextField();
		txtScore.setBounds(150, 100, 140, 20);
		this.getContentPane().add(txtScore);

		JButton btnSave = new JButton("保存");
		btnSave.setBounds(150, 130, 60, 20);
		btnSave.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				Boolean ret = false;
				// 1.验证输入
				if (txtScore.getText().length() == 0) {
					JOptionPane.showMessageDialog(null, "成绩不能为空");
					return;
				}
				Double score = 0.0d;
				try {
					String s = txtScore.getText();
					score = Double.valueOf(s);
					if(score<0||score>100) {
						JOptionPane.showMessageDialog(null, "成绩有效范围0-100");
					}
				} catch (Exception ex) {
					JOptionPane.showMessageDialog(null, "成绩只能是数字");
					return;
				}
				// 2.准备需提交的数据
				StudentCourse mo = studentCourseBll.getById(id);
				mo.setScore(score);
				mo.setInputScoreTime(LocalDateTime.now());
				// 3.提交数据库
				ret = studentCourseBll.update(mo);
				// 4.提示并关闭窗口
				if (ret) {
					owner.mustSaveFlag = true;
					dispose();
				}
			}
		});
		this.getContentPane().add(btnSave);

		JButton btnCancel = new JButton("取消");
		btnCancel.setBounds(230, 130, 60, 20);
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				owner.mustSaveFlag = false;
				dispose();
			}
		});
		this.getContentPane().add(btnCancel);

		// 填充数据
		StudentCourse mo = studentCourseBll.getById(id);
		txtTerm.setText(mo.getTerm());
		txtStudentName.setText(new StudentBll().getById(mo.getStudentId()).getName());
		txtCourseName.setText(new CourseBll().getById(mo.getCourseId()).getName());
		if(mo.getScore()!=null) {
			txtScore.setText(mo.getScore()+"");
		}
	}
}
