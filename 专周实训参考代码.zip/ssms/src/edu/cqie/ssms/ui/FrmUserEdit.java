package edu.cqie.ssms.ui;

import java.awt.Container;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;

import edu.cqie.ssms.bll.UserBll;
import edu.cqie.ssms.domain.User;

@SuppressWarnings({ "unchecked", "rawtypes", "serial" })
public class FrmUserEdit extends JDialog {
	UserBll bll = new UserBll();
	Integer id;
	FrmUserList owner;
	
	public FrmUserEdit(FrmUserList owner, int id) {
		this.setTitle("编辑用户信息");
		this.setModal(true);
		this.id = id;
		this.owner=owner;
		InitializeComponent();
	}
	// 初始化页面的部件
	private void InitializeComponent() {
		// 1.窗口
		this.setLayout(null);
		this.setSize(400, 230);
		this.setLocationRelativeTo(null);
		this.setResizable(false);
		
		JLabel lblName = new JLabel("用户名:");
		lblName.setBounds(40, 10, 100, 20);
		TextField txtName = new TextField();
		txtName.setBounds(150, 10, 140, 20);

		JLabel lblAccount = new JLabel("登录账号:");
		lblAccount.setBounds(40, 40, 100, 20);
		TextField txtAccount = new TextField();
		txtAccount.setBounds(150, 40, 140, 20);

		JLabel lblPassword = new JLabel("登录密码:");
		lblPassword.setBounds(40, 70, 100, 20);
		TextField txtPassword = new TextField();
		txtPassword.setBounds(150, 70, 140, 20);

		JLabel lblUserType = new JLabel("用户类型:");
		lblUserType.setBounds(40, 100, 100, 20);
		String[] optionsUserType= {"管理员","教师","学生"};
		JComboBox cbUserType=new JComboBox(optionsUserType);
		cbUserType.setBounds(150, 100, 140, 20);
		cbUserType.setEditable(true);
		
		JLabel lblStatus = new JLabel("状态:");
		lblStatus.setBounds(40, 130, 100, 20);
		ButtonGroup bg = new ButtonGroup();
		JRadioButton rbStatus01 = new JRadioButton("正常");
		rbStatus01.setBounds(150, 130, 60, 20);
		JRadioButton rbStatus02 = new JRadioButton("禁用");
		rbStatus02.setBounds(220, 130, 60, 20);
		bg.add(rbStatus01);
		bg.add(rbStatus02);

		JButton btnSave = new JButton("保存");
		JButton btnCancel = new JButton("取消");
		btnSave.setBounds(150, 160, 60, 20);
		btnCancel.setBounds(230, 160, 60, 20);

		Container container = this.getContentPane();
		container.add(lblName);
		container.add(txtName);
		container.add(lblAccount);
		container.add(txtAccount);
		container.add(lblPassword);
		container.add(txtPassword);
		container.add(lblUserType);
		container.add(cbUserType);
		container.add(lblStatus);
		container.add(rbStatus01);
		container.add(rbStatus02);
		container.add(btnSave);
		container.add(btnCancel);

		if (id > 0) {
			User mo = bll.getById(id);

			txtName.setText(mo.getName());
			txtAccount.setText(mo.getAccount());
			txtPassword.setText(mo.getPassword());
			
			cbUserType.setSelectedIndex(mo.getUserType()-1);
			
			if (mo.getStatus() == 0) {
				rbStatus01.setSelected(true);
			}
			if (mo.getStatus() == 1) {
				rbStatus02.setSelected(true);
			}
		}else {
			cbUserType.setSelectedIndex(2);
			rbStatus01.setSelected(true);
		}
		// 保存按钮的click事件
		btnSave.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				Boolean ret = false;
				// 1.验证输入
				if (txtName.getText().length() == 0) {
					JOptionPane.showMessageDialog(null, "用户名不能为空");
					return;
				}
				if (txtAccount.getText().length() == 0) {
					JOptionPane.showMessageDialog(null, "登录账号不能为空");
					return;
				}
				// 2.准备需提交的数据
				User mo = new User();
				mo.setId(id);
				mo.setName(txtName.getText());
				mo.setAccount(txtAccount.getText());
				mo.setPassword(txtPassword.getText());
				mo.setUserType(cbUserType.getSelectedIndex()+1);
				if (rbStatus01.isSelected()) {
					mo.setStatus(0);
				}
				if (rbStatus02.isSelected()) {
					mo.setStatus(1);
				}
				// 3.提交数据库
				if (id > 0) {
					ret = bll.update(mo);
				} else {
					ret = bll.add(mo);
				}
				// 4.提示并关闭窗口
				if (ret) {
					owner.mustSaveFlag = true;
					dispose();
				}
			}
		});
		// 取消按钮的click事件
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				owner.mustSaveFlag = false;
				dispose();
			}
		});
	}
}
