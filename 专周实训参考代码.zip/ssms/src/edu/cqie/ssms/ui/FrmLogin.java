package edu.cqie.ssms.ui;

import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;

import edu.cqie.ssms.bll.UserBll;
import edu.cqie.ssms.domain.User;

@SuppressWarnings({ "serial" })
public class FrmLogin extends JFrame {
	public FrmLogin() {
		InitializeComponent();
	}

	// 初始化页面的部件
	private void InitializeComponent() {
		this.setTitle("系统登录");
		this.setLayout(null);
		this.setSize(350, 130);
		this.setLocationRelativeTo(null);
		this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

//		// 读取背景图片文件
//		ImageIcon bg = new ImageIcon("src/loginBg.png");
//		// 图片添加到标签里,标签大小设为和图片大小同
//		JLabel lblBackground = new JLabel(bg);
//		lblBackground.setSize(bg.getIconWidth(), bg.getIconHeight());
//		// 标签放在分层面板的最底层
//		this.getLayeredPane().add(lblBackground, Integer.valueOf(Integer.MIN_VALUE));
//		// 2.把窗口面板设为内容面板并设为透明、流动布局。
		JPanel pan = (JPanel) this.getContentPane();
//		pan.setOpaque(false);
//		pan.setLayout(null);

		JLabel lblAccount = new JLabel("登录账号:");
		lblAccount.setBounds(40, 10, 100, 20);
		pan.add(lblAccount);
		TextField txtAccount = new TextField();
		txtAccount.setBounds(150, 10, 140, 20);
		txtAccount.setText("admin");
		pan.add(txtAccount);

		JLabel lblPassword = new JLabel("登录密码:");
		lblPassword.setBounds(40, 40, 100, 20);
		pan.add(lblPassword);
		JPasswordField txtPassword = new JPasswordField();
		txtPassword.setBounds(150, 40, 140, 20);
		txtPassword.setText("123456");
		pan.add(txtPassword);

		JButton btnOk = new JButton("登录");
		btnOk.setBounds(150, 65, 60, 20);
		pan.add(btnOk);

		JButton btnReset = new JButton("重置");
		btnReset.setBounds(230, 65, 60, 20);
		pan.add(btnReset);

		// 读取背景图片文件
		ImageIcon bg = new ImageIcon("src/loginBg.png");
		// 图片添加到标签里,标签大小设为和图片大小同
		JLabel lblBackground = new JLabel(bg);
		lblBackground.setSize(bg.getIconWidth(), bg.getIconHeight());
		// 标签放在分层面板的最底层
		pan.add(lblBackground, Integer.valueOf(Integer.MIN_VALUE));
		// 2.把窗口面板设为内容面板并设为透明、流动布局。		
		pan.setOpaque(false);
		pan.setLayout(null);
		
		
		// 登录按钮click
		btnOk.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// 获取用户输入值
				String iptAccount = txtAccount.getText();
				String iptPassword = String.valueOf(txtPassword.getPassword());

				UserBll userBll = new UserBll();
				User user = userBll.getLoginUser(iptAccount, iptPassword);
				if (user == null) {
					JOptionPane.showMessageDialog(null, "账号或密码错误，请重新输入", "错误", JOptionPane.ERROR_MESSAGE);
				} else {
					// JOptionPane.showMessageDialog(null, "登录成功");
					// 销毁登录窗口
					dispose();
					// 打开主窗口
					new FrmHome(user).setVisible(true);
				}
			}
		});
		// 重置按钮click
		btnReset.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				txtAccount.setText("");
				txtPassword.setText("");
			}
		});
	}

	public static void main(String[] args) {
		java.awt.EventQueue.invokeLater(new Runnable() {
			public void run() {
				new FrmLogin().setVisible(true);
			}
		});
	}
}
