package edu.cqie.ssms.ui;

import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;

import edu.cqie.ssms.bll.CourseBll;
import edu.cqie.ssms.domain.Course;

@SuppressWarnings({ "serial" })
public class FrmCourseEdit extends JDialog {
	CourseBll courseBll = new CourseBll();
	Integer id;
	FrmCourseList owner;

	public FrmCourseEdit(FrmCourseList owner, int id) {
		this.setTitle("编辑课程信息");
		this.setModal(true);
		this.id = id;
		this.owner = owner;
		InitializeComponent();
	}

	// 初始化页面的部件
	private void InitializeComponent() {
		// 1.窗口
		this.setLayout(null);
		this.setSize(380, 200);
		this.setLocationRelativeTo(null);
		this.setResizable(false);

		JLabel lblName = new JLabel("课程名称:");
		lblName.setBounds(40, 10, 100, 20);
		this.getContentPane().add(lblName);
		TextField txtName = new TextField();
		txtName.setBounds(150, 10, 140, 20);
		this.getContentPane().add(txtName);

		JLabel lblCode = new JLabel("课程代码:");
		lblCode.setBounds(40, 40, 100, 20);
		this.getContentPane().add(lblCode);
		TextField txtCode = new TextField();
		txtCode.setBounds(150, 40, 140, 20);
		this.getContentPane().add(txtCode);

		JLabel lblCredit = new JLabel("学分:");
		lblCredit.setBounds(40, 70, 100, 20);
		this.getContentPane().add(lblCredit);
		TextField txtCredit = new TextField();
		txtCredit.setBounds(150, 70, 140, 20);
		this.getContentPane().add(txtCredit);

		JLabel lblCourseType = new JLabel("课程类型:");
		lblCourseType.setBounds(40, 100, 100, 20);
		this.getContentPane().add(lblCourseType);
		ButtonGroup bgCourseType = new ButtonGroup();
		JRadioButton rbCourseType01 = new JRadioButton("必修");
		rbCourseType01.setBounds(150, 100, 60, 20);
		JRadioButton rbCourseType02 = new JRadioButton("选修");
		rbCourseType02.setBounds(220, 100, 60, 20);
		bgCourseType.add(rbCourseType01);
		bgCourseType.add(rbCourseType02);
		this.getContentPane().add(rbCourseType01);
		this.getContentPane().add(rbCourseType02);

		JButton btnSave = new JButton("保存");
		btnSave.setBounds(150, 130, 60, 20);
		btnSave.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				Boolean ret = false;
				// 1.验证输入
				if (txtName.getText().length() == 0) {
					JOptionPane.showMessageDialog(null, "课程名称不能为空");
					return;
				}
				if (txtCode.getText().length() == 0) {
					JOptionPane.showMessageDialog(null, "课程代码不能为空");
					return;
				}
				Integer credit = 0;
				if (txtCredit.getText().length() == 0) {
					JOptionPane.showMessageDialog(null, "学分不能为空");
					return;
				} else {
					try {
						String s = txtCredit.getText();
						credit = Integer.parseInt(s);
					} catch (Exception ex) {
						JOptionPane.showMessageDialog(null, "学分必须是数字");
						return;
					}
				}
				// 2.准备需提交的数据
				Course mo = new Course();
				mo.setId(id);
				mo.setName(txtName.getText());
				mo.setCode(txtCode.getText());
				mo.setCredit(credit);
				if (rbCourseType01.isSelected()) {
					mo.setCourseType(1);
				}
				if (rbCourseType02.isSelected()) {
					mo.setCourseType(2);
				}
				// 3.提交数据库
				if (id > 0) {
					ret = courseBll.update(mo);
				} else {
					ret = courseBll.add(mo);
				}
				// 4.提示并关闭窗口
				if (ret) {
					owner.mustSaveFlag = true;
					dispose();
				}
			}
		});
		this.getContentPane().add(btnSave);

		JButton btnCancel = new JButton("取消");
		btnCancel.setBounds(230, 130, 60, 20);
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				owner.mustSaveFlag = false;
				dispose();
			}
		});
		this.getContentPane().add(btnCancel);

		// 填充数据
		if (id > 0) {
			Course mo = courseBll.getById(id);
			txtName.setText(mo.getName());
			txtCode.setText(mo.getCode());
			txtCredit.setText(mo.getCredit() + "");
			if (mo.getCourseType() == 1) {
				rbCourseType01.setSelected(true);
			}
			if (mo.getCourseType() == 2) {
				rbCourseType02.setSelected(true);
			}
		}
	}
}
