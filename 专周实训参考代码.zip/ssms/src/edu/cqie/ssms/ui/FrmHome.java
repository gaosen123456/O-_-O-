package edu.cqie.ssms.ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyVetoException;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.Border;

import edu.cqie.ssms.domain.User;

@SuppressWarnings("serial")
public class FrmHome extends JFrame {
	JButton prevBtn = null;
	Border redBorder=BorderFactory.createLineBorder(Color.RED);
	Border crudeBorder=null;
	JDesktopPane desktop = null;
	FrmClazzList frmClazzList = null;
	FrmUserList frmUserList = null;
	FrmStudentList frmStudentList = null;
	FrmTeacherList frmTeacherList = null;
	FrmSelectCourseList frmSelectCourseList = null;
	FrmCourseList frmCourseList = null;
	FrmInputScoreList frmInputScoreList = null;
	FrmStudentScoreList frmStudentScoreList = null;
	User loginUser;

	public FrmHome(User user) {
		this.loginUser = user;
		this.setTitle("学生成绩查询系统");
		this.setSize(1024, 800);
		this.setLocationRelativeTo(null);
		this.setResizable(false);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);

		desktop = new JDesktopPane();
		desktop.setLayout(new BorderLayout());
		this.setContentPane(desktop);

		try {
			ImageIcon background=new ImageIcon("src/bg.png");
			JLabel lblBackground = new JLabel(background);
			this.getContentPane().add(lblBackground, BorderLayout.CENTER);
		} catch (Exception e) {
		}
		JPanel panelHeader = new JPanel();
		panelHeader.setLayout(new GridLayout(1, 10));
		this.getContentPane().add(panelHeader, BorderLayout.NORTH);

		JButton btnUser = new JButton("用户管理");
		panelHeader.add(btnUser);

		JButton btnCourse = new JButton("课程管理");
		panelHeader.add(btnCourse);

		JButton btnTeacher = new JButton("教师管理");
		panelHeader.add(btnTeacher);

		JButton btnClazz = new JButton("班级管理");
		panelHeader.add(btnClazz);

		JButton btnStudent = new JButton("学生管理");
		panelHeader.add(btnStudent);

		JButton btnSelectCourse = new JButton("选课管理");
		panelHeader.add(btnSelectCourse);

		JButton btnInputScore = new JButton("成绩管理");
		panelHeader.add(btnInputScore);

		JButton btnQueryScore = new JButton("成绩查询");
		panelHeader.add(btnQueryScore);

		JButton btnExit = new JButton("退出登录");
		panelHeader.add(btnExit);

		JLabel lblLoginUser = new JLabel("欢迎:" + user.getName());
		panelHeader.add(lblLoginUser);

		// 底部
		JLabel lblBottom = new JLabel("重庆工程学院 付祥明 荣誉出品", JLabel.CENTER);
		this.getContentPane().add(lblBottom, BorderLayout.SOUTH);

		// 控制按钮可用状态
		btnExit.setEnabled(true);

		if (user.getUserType() == 1) {
			btnStudent.setEnabled(true);
			btnClazz.setEnabled(true);
			btnTeacher.setEnabled(true);
			btnCourse.setEnabled(true);
			btnUser.setEnabled(true);
			btnSelectCourse.setEnabled(false);
			btnInputScore.setEnabled(false);
			btnQueryScore.setEnabled(false);
		}
		if (user.getUserType() == 2) {
			btnStudent.setEnabled(false);
			btnClazz.setEnabled(false);
			btnTeacher.setEnabled(false);
			btnCourse.setEnabled(false);
			btnUser.setEnabled(false);
			btnSelectCourse.setEnabled(false);
			btnInputScore.setEnabled(true);
			btnQueryScore.setEnabled(false);
		}
		if (user.getUserType() == 3) {
			btnStudent.setEnabled(false);
			btnClazz.setEnabled(false);
			btnTeacher.setEnabled(false);
			btnCourse.setEnabled(false);
			btnUser.setEnabled(false);
			btnSelectCourse.setEnabled(true);
			btnInputScore.setEnabled(false);
			btnQueryScore.setEnabled(true);
		}
		// 绑定按钮事件
		btnExit.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// 销毁主窗口
				dispose();
				// 打开登录窗口
				new FrmLogin().setVisible(true);
			}
		});
		btnStudent.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
//				// 恢复上次选中按钮的边框
//				if (prevBtn != null) {
//					prevBtn.setBorder(crudeBorder);
//				}
//				// 修改边框
//				btnStudent.setBorder(redBorder);
//				// 记忆选中按钮
//				prevBtn = btnStudent;
				// 打开学生管理窗口
				if (frmStudentList == null) {
					frmStudentList = new FrmStudentList();
					frmStudentList.setLocation(20, 120);
					desktop.add(frmStudentList);
				} else {
					try {
						frmStudentList.setSelected(true);
					} catch (PropertyVetoException e1) {
						e1.printStackTrace();
					}
				}
				frmStudentList.show();
			}
		});

		btnClazz.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// 恢复上次选中按钮的边框
				if (prevBtn != null) {
					prevBtn.setBorder(crudeBorder);
				}
				// 修改边框
				btnClazz.setBorder(redBorder);
				// 记忆选中按钮
				prevBtn = btnClazz;
				// 打开班级管理窗口
				if (frmClazzList == null) {
					frmClazzList = new FrmClazzList();
					frmClazzList.setLocation(20, 120);
					desktop.add(frmClazzList);
				} else {
					try {
						frmClazzList.setSelected(true);
					} catch (PropertyVetoException e1) {
						e1.printStackTrace();
					}
				}
				frmClazzList.show();
			}
		});

		btnTeacher.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// 恢复上次选中按钮的边框
				if (prevBtn != null) {
					prevBtn.setBorder(crudeBorder);
				}
				// 修改边框
				btnTeacher.setBorder(redBorder);
				// 记忆选中按钮
				prevBtn = btnTeacher;
				// 打开教师管理窗口
				if (frmTeacherList == null) {
					frmTeacherList = new FrmTeacherList();
					frmTeacherList.setLocation(20, 120);
					desktop.add(frmTeacherList);
				} else {
					try {
						frmTeacherList.setSelected(true);
					} catch (PropertyVetoException e1) {
						e1.printStackTrace();
					}
				}
				frmTeacherList.show();
			}
		});

		btnCourse.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// 恢复上次选中按钮的边框
				if (prevBtn != null) {
					prevBtn.setBorder(crudeBorder);
				}
				// 修改边框
				btnCourse.setBorder(redBorder);
				// 记忆选中按钮
				prevBtn = btnCourse;
				// 打开课程管理窗口
				if (frmCourseList == null) {
					frmCourseList = new FrmCourseList();
					frmCourseList.setLocation(20, 120);
					desktop.add(frmCourseList);
				} else {
					try {
						frmCourseList.setSelected(true);
					} catch (PropertyVetoException e1) {
						e1.printStackTrace();
					}
				}
				frmCourseList.show();
			}
		});

		btnUser.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// 恢复上次选中按钮的边框
				if (prevBtn != null) {
					prevBtn.setBorder(crudeBorder);
				}
				// 修改边框
				btnUser.setBorder(redBorder);
				// 记忆选中按钮
				prevBtn = btnUser;
				// 打开用户管理窗口
				if (frmUserList == null) {
					frmUserList = new FrmUserList();
					frmUserList.setLocation(20, 120);
					desktop.add(frmUserList);
				} else {
					try {
						frmUserList.setSelected(true);
					} catch (PropertyVetoException e1) {
						e1.printStackTrace();
					}
				}
				frmUserList.show();
			}
		});

		btnSelectCourse.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// 恢复上次选中按钮的边框
				if (prevBtn != null) {
					prevBtn.setBorder(crudeBorder);
				}
				// 修改边框
				btnSelectCourse.setBorder(redBorder);
				// 记忆选中按钮
				prevBtn = btnSelectCourse;
				// 打开选课管理窗口
				if (frmSelectCourseList == null) {
					frmSelectCourseList = new FrmSelectCourseList(loginUser.getId());
					frmSelectCourseList.setLocation(20, 120);
					desktop.add(frmSelectCourseList);
				} else {
					try {
						frmSelectCourseList.setSelected(true);
					} catch (PropertyVetoException e1) {
						e1.printStackTrace();
					}
				}
				frmSelectCourseList.show();
			}
		});

		btnInputScore.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// 恢复上次选中按钮的边框
				if (prevBtn != null) {
					prevBtn.setBorder(crudeBorder);
				}
				// 修改边框
				btnInputScore.setBorder(redBorder);
				// 记忆选中按钮
				prevBtn = btnInputScore;
				// 打开成绩管理窗口
				if (frmInputScoreList == null) {
					frmInputScoreList = new FrmInputScoreList(loginUser.getId());
					frmInputScoreList.setLocation(20, 120);
					desktop.add(frmInputScoreList);
				} else {
					try {
						frmInputScoreList.setSelected(true);
					} catch (PropertyVetoException e1) {
						e1.printStackTrace();
					}
				}
				frmInputScoreList.show();
			}
		});

		btnQueryScore.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// 恢复上次选中按钮的边框
				if (prevBtn != null) {
					prevBtn.setBorder(crudeBorder);
				}
				// 修改边框
				btnQueryScore.setBorder(redBorder);
				// 记忆选中按钮
				prevBtn = btnQueryScore;
				// 打开成绩查询窗口
				if (frmStudentScoreList == null) {
					frmStudentScoreList = new FrmStudentScoreList(loginUser.getId());
					frmStudentScoreList.setLocation(20, 120);
					desktop.add(frmStudentScoreList);
				} else {
					try {
						frmStudentScoreList.setSelected(true);
					} catch (PropertyVetoException e1) {
						e1.printStackTrace();
					}
				}
				frmStudentScoreList.show();
			}
		});
		crudeBorder=btnExit.getBorder();
	}

}
