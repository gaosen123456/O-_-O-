package edu.cqie.ssms.ui;

import java.awt.Component;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.plaf.basic.BasicComboBoxRenderer;

import edu.cqie.ssms.bll.TeacherBll;
import edu.cqie.ssms.bll.UserBll;
import edu.cqie.ssms.domain.SelectListItem;
import edu.cqie.ssms.domain.Teacher;
import edu.cqie.ssms.domain.User;

@SuppressWarnings({ "rawtypes", "serial", "unchecked" })
public class FrmTeacherEdit extends JDialog {
	TeacherBll teacherBll = new TeacherBll();
	Integer id;
	FrmTeacherList owner;

	public FrmTeacherEdit(FrmTeacherList owner, int id) {
		this.setTitle("编辑教师信息");
		this.setModal(true);
		this.id = id;
		this.owner = owner;
		InitializeComponent();
	}

	// 初始化页面的部件
	private void InitializeComponent() {
		// 1.窗口
		this.setLayout(null);
		this.setSize(380, 260);
		this.setLocationRelativeTo(null);
		this.setResizable(false);

		JLabel lblName = new JLabel("姓名:");
		lblName.setBounds(40, 10, 100, 20);
		this.getContentPane().add(lblName);
		TextField txtName = new TextField();
		txtName.setBounds(150, 10, 140, 20);
		this.getContentPane().add(txtName);

		JLabel lblGender = new JLabel("性别:");
		lblGender.setBounds(40, 40, 100, 20);
		this.getContentPane().add(lblGender);
		ButtonGroup bgGender = new ButtonGroup();
		JRadioButton rbGender01 = new JRadioButton("男");
		rbGender01.setBounds(150, 40, 60, 20);
		JRadioButton rbGender02 = new JRadioButton("女");
		rbGender02.setBounds(220, 40, 60, 20);
		bgGender.add(rbGender01);
		bgGender.add(rbGender02);
		this.getContentPane().add(rbGender01);
		this.getContentPane().add(rbGender02);

		JLabel lblMobile = new JLabel("手机号:");
		lblMobile.setBounds(40, 70, 100, 20);
		this.getContentPane().add(lblMobile);
		TextField txtMobile = new TextField();
		txtMobile.setBounds(150, 70, 140, 20);
		this.getContentPane().add(txtMobile);

		JLabel lblWorkNum = new JLabel("工号:");
		lblWorkNum.setBounds(40, 100, 100, 20);
		this.getContentPane().add(lblWorkNum);
		TextField txtWorkNum = new TextField();
		txtWorkNum.setBounds(150, 100, 140, 20);
		this.getContentPane().add(txtWorkNum);

		JLabel lblUserId = new JLabel("绑定用户:");
		lblUserId.setBounds(40, 130, 100, 20);
		this.getContentPane().add(lblUserId);
		List<SelectListItem> optionsUserId = getOptionsForTeacherUser(id);
		JComboBox cbUserId = new JComboBox();
		for (SelectListItem sli : optionsUserId) {
			cbUserId.addItem(sli);
		}
		cbUserId.setBounds(150, 130, 140, 20);
		cbUserId.setRenderer(new SelectListItemRenderer());
		this.getContentPane().add(cbUserId);

		JButton btnSave = new JButton("保存");
		btnSave.setBounds(150, 160, 60, 20);
		btnSave.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				Boolean ret = false;
				// 1.验证输入
				if (txtName.getText().length() == 0) {
					JOptionPane.showMessageDialog(null, "姓名不能为空");
					return;
				}
				// 2.准备需提交的数据
				Teacher mo = new Teacher();
				mo.setId(id);
				mo.setName(txtName.getText());
				if (rbGender01.isSelected()) {
					mo.setGender("男");
				}
				if (rbGender02.isSelected()) {
					mo.setGender("女");
				}
				mo.setMobile(txtMobile.getText());
				mo.setWorkNum(txtWorkNum.getText());

				if (cbUserId.getSelectedItem() != null) {
					SelectListItem sli = (SelectListItem) cbUserId.getSelectedItem();
					mo.setUserId(Integer.parseInt(sli.getValue()));
				}
				// 3.提交数据库
				if (id > 0) {
					ret = teacherBll.update(mo);
				} else {
					ret = teacherBll.add(mo);
				}
				// 4.提示并关闭窗口
				if (ret) {
					owner.mustSaveFlag = true;
					dispose();
				}
			}
		});
		this.getContentPane().add(btnSave);

		JButton btnCancel = new JButton("取消");
		btnCancel.setBounds(230, 160, 60, 20);
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				owner.mustSaveFlag = false;
				dispose();
			}
		});
		this.getContentPane().add(btnCancel);
		// 填充数据
		if (id > 0) {
			Teacher mo = teacherBll.getById(id);
			txtName.setText(mo.getName());
			if (mo.getGender() == "男") {
				rbGender01.setSelected(true);
			}
			if (mo.getGender() == "女") {
				rbGender02.setSelected(true);
			}
			txtMobile.setText(mo.getMobile());
			txtWorkNum.setText(mo.getWorkNum());

			for (SelectListItem item : optionsUserId) {
				if (item.getValue().equals(mo.getUserId() + "")) {
					cbUserId.setSelectedItem(item);
					break;
				}
			}
		}
	}

	// 绑定教师用户备选项
	private List<SelectListItem> getOptionsForTeacherUser(Integer teacherId) {
		List<SelectListItem> ret = new ArrayList<>();
		// 1.获取数据库的值
		UserBll userBll = new UserBll();
		List<User> all = userBll.getTeacherUser(teacherId);
		// 2.准备返回值
		for (User item : all) {
			SelectListItem sli = new SelectListItem();
			sli.setValue(item.getId() + "");
			sli.setText(item.getAccount());
			ret.add(sli);
		}
		return ret;
	}

	// SelectListItemR下拉单选的渲染器
	class SelectListItemRenderer extends BasicComboBoxRenderer {
		public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected,
				boolean cellHasFocus) {
			super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
			if (value != null) {
				SelectListItem item = (SelectListItem) value;
				if (index == -1) {
					setText(item.getText());
				} else {
					setText(item.getText());
				}
			}
			return this;
		}
	}
}
