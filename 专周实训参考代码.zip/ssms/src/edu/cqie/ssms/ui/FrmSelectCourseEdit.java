package edu.cqie.ssms.ui;

import java.awt.Component;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.plaf.basic.BasicComboBoxRenderer;

import edu.cqie.ssms.bll.CourseBll;
import edu.cqie.ssms.bll.StudentBll;
import edu.cqie.ssms.bll.StudentCourseBll;
import edu.cqie.ssms.bll.TeacherBll;
import edu.cqie.ssms.domain.SelectListItem;
import edu.cqie.ssms.domain.Student;
import edu.cqie.ssms.domain.StudentCourse;

@SuppressWarnings({ "serial", "rawtypes", "unchecked" })
public class FrmSelectCourseEdit extends JDialog {
	StudentCourseBll studentCourseBll = new StudentCourseBll();
	CourseBll courseBll = new CourseBll();
	TeacherBll teacherBll = new TeacherBll();
	StudentBll studentBll = new StudentBll();

	Integer id;
	FrmSelectCourseList owner;
	Integer loginUserId;

	public FrmSelectCourseEdit(FrmSelectCourseList owner, int id, int loginUserId) {
		this.setTitle("学生选课");
		this.setModal(true);
		this.id = id;
		this.owner = owner;
		this.loginUserId = loginUserId;
		InitializeComponent();
	}

	// 初始化页面的部件
	private void InitializeComponent() {
		// 1.窗口
		this.setLayout(null);
		this.setSize(380, 200);
		this.setLocationRelativeTo(null);
		this.setResizable(false);

		JLabel lblTerm = new JLabel("学期:");
		lblTerm.setBounds(40, 10, 50, 20);
		this.getContentPane().add(lblTerm);
		TextField txtTerm = new TextField();
		txtTerm.setBounds(100, 10, 230, 20);
		this.getContentPane().add(txtTerm);

		JLabel lblCourseId = new JLabel("课程:");
		lblCourseId.setBounds(40, 40, 50, 20);
		this.getContentPane().add(lblCourseId);
		JComboBox cbCourseId = new JComboBox();
		List<SelectListItem> optionsCourseId = courseBll.getOptions();
		for (SelectListItem sli : optionsCourseId) {
			cbCourseId.addItem(sli);
		}
		cbCourseId.setBounds(100, 40, 230, 20);
		cbCourseId.setRenderer(new SelectListItemRenderer());
		this.getContentPane().add(cbCourseId);

		JLabel lblTeacherId = new JLabel("教师:");
		lblTeacherId.setBounds(40, 70, 50, 20);
		this.getContentPane().add(lblTeacherId);
		JComboBox cbTeacherId = new JComboBox();
		List<SelectListItem> optionsTeacherId = teacherBll.getOptions();
		for (SelectListItem sli : optionsTeacherId) {
			cbTeacherId.addItem(sli);
		}
		cbTeacherId.setBounds(100, 70, 230, 20);
		cbTeacherId.setRenderer(new SelectListItemRenderer());
		this.getContentPane().add(cbTeacherId);

		JButton btnSave = new JButton("保存");
		btnSave.setBounds(150, 100, 60, 20);
		btnSave.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				Boolean ret = false;
				// 1.验证输入
				// 学期
				if (txtTerm.getText().length() == 0) {
					JOptionPane.showMessageDialog(null, "学期不能为空");
					return;
				}
				// 课程
				// 教师
				// 2.准备需提交的数据
				StudentCourse mo = new StudentCourse();
				mo.setId(id);
				mo.setTerm(txtTerm.getText());
				if (cbCourseId.getSelectedItem() != null) {
					SelectListItem sli = (SelectListItem) cbCourseId.getSelectedItem();
					mo.setCourseId(Integer.parseInt(sli.getValue()));
				}
				if (cbTeacherId.getSelectedItem() != null) {
					SelectListItem sli = (SelectListItem) cbTeacherId.getSelectedItem();
					mo.setTeacherId(Integer.parseInt(sli.getValue()));
				}
				Student loginStudent = studentBll.mapUserIdStudent(loginUserId);
				if (loginStudent != null) {
					mo.setStudentId(loginStudent.getId());
				}
				// 3.提交数据库
				if (id > 0) {
					ret = studentCourseBll.update(mo);
				} else {
					ret = studentCourseBll.add(mo);
				}
				// 4.提示并关闭窗口
				if (ret) {
					owner.mustSaveFlag = true;
					dispose();
				}
			}
		});
		this.getContentPane().add(btnSave);

		JButton btnCancel = new JButton("取消");
		btnCancel.setBounds(230, 100, 60, 20);
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				owner.mustSaveFlag = false;
				dispose();
			}
		});
		this.getContentPane().add(btnCancel);
		
		// 填充数据
		if (id > 0) {
			StudentCourse mo = studentCourseBll.getById(id);
			txtTerm.setText(mo.getTerm());
			
			for (SelectListItem item : optionsCourseId) {
				if (item.getValue().equals(mo.getCourseId() + "")) {
					cbCourseId.setSelectedItem(item);
					break;
				}
			}
			
			for (SelectListItem item : optionsTeacherId) {
				if (item.getValue().equals(mo.getTeacherId() + "")) {
					cbTeacherId.setSelectedItem(item);
					break;
				}
			}
		}
	}

	// SelectListItemR下拉单选的渲染器
	class SelectListItemRenderer extends BasicComboBoxRenderer {
		public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected,
				boolean cellHasFocus) {
			super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
			if (value != null) {
				SelectListItem item = (SelectListItem) value;
				if (index == -1) {
					setText(item.getText());
				} else {
					setText(item.getText());
				}
			}
			return this;
		}
	}
}
