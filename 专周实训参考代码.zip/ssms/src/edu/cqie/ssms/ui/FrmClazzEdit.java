package edu.cqie.ssms.ui;

import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import edu.cqie.ssms.bll.ClazzBll;
import edu.cqie.ssms.domain.Clazz;

@SuppressWarnings({ "serial" })
public class FrmClazzEdit extends JDialog {
	ClazzBll clazzBll = new ClazzBll();
	Integer id;
	FrmClazzList owner;
	
	public FrmClazzEdit(FrmClazzList owner, int id) {
		this.setTitle("编辑班级信息");
		this.setModal(true);
		this.id = id;
		this.owner=owner;
		InitializeComponent();
	}

	// 初始化页面的部件
	private void InitializeComponent() {
		// 1.窗口
		this.setLayout(null);
		this.setSize(380, 200);
		this.setLocationRelativeTo(null);
		this.setResizable(false);

		JLabel lblName = new JLabel("班级名称:");
		lblName.setBounds(40, 10, 100, 20);
		this.getContentPane().add(lblName);
		TextField txtName = new TextField();
		txtName.setBounds(150, 10, 140, 20);
		this.getContentPane().add(txtName);

		JLabel lblCode = new JLabel("班级代码:");
		lblCode.setBounds(40, 40, 100, 20);
		this.getContentPane().add(lblCode);
		TextField txtCode = new TextField();
		txtCode.setBounds(150, 40, 140, 20);
		this.getContentPane().add(txtCode);

		JLabel lblMajor = new JLabel("专业方向:");
		lblMajor.setBounds(40, 70, 100, 20);
		this.getContentPane().add(lblMajor);
		TextField txtMajor = new TextField();
		txtMajor.setBounds(150, 70, 140, 20);
		this.getContentPane().add(txtMajor);

		JLabel lblFaculty = new JLabel("隶属院系:");
		lblFaculty.setBounds(40, 100, 100, 20);
		this.getContentPane().add(lblFaculty);
		TextField txtFaculty = new TextField();
		txtFaculty.setBounds(150, 100, 140, 20);
		this.getContentPane().add(txtFaculty);

		JButton btnSave = new JButton("保存");
		btnSave.setBounds(150, 130, 60, 20);
		btnSave.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				Boolean ret = false;
				// 1.验证输入
				if (txtName.getText().length() == 0) {
					JOptionPane.showMessageDialog(null, "专业名称不能为空");
					return;
				}
				// 2.准备需提交的数据
				Clazz mo = new Clazz();
				mo.setId(id);
				mo.setName(txtName.getText());
				mo.setCode(txtCode.getText());
				mo.setMajor(txtMajor.getText());
				mo.setFaculty(txtFaculty.getText());
				// 3.提交数据库
				if (id > 0) {
					ret = clazzBll.update(mo);
				} else {
					ret = clazzBll.add(mo);
				}
				// 4.提示并关闭窗口
				if (ret) {
					owner.mustSaveFlag=true;
					dispose();
				}
			}
		});
		this.getContentPane().add(btnSave);

		JButton btnCancel = new JButton("取消");
		btnCancel.setBounds(230, 130, 60, 20);
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				owner.mustSaveFlag=false;
				dispose();
			}
		});
		this.getContentPane().add(btnCancel);

		// 填充数据
		if (id > 0) {
			Clazz mo = clazzBll.getById(id);
			txtName.setText(mo.getName());
			txtCode.setText(mo.getCode());
			txtMajor.setText(mo.getMajor());
			txtFaculty.setText(mo.getFaculty());
		}
	}
}
