package edu.cqie.ssms.ui;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.swing.JButton;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import edu.cqie.ssms.bll.CourseBll;
import edu.cqie.ssms.bll.StudentBll;
import edu.cqie.ssms.bll.StudentCourseBll;
import edu.cqie.ssms.bll.TeacherBll;
import edu.cqie.ssms.domain.Course;
import edu.cqie.ssms.domain.Student;
import edu.cqie.ssms.domain.StudentCourse;
import edu.cqie.ssms.domain.Teacher;

@SuppressWarnings("serial")
public class FrmStudentScoreList extends JInternalFrame {
	JTable table = null;
	DefaultTableModel dtm = null;

	JButton btnFirst;
	JButton btnPrev;
	JButton btnNext;
	JButton btnLast;
	TextField txtPageIndex;
	JLabel lblPageInfo;
	Integer pageIndex = 1;// 页号
	Integer pageSize = 19;// 每页记录数
	Integer pageCount = 0;// 总页数

	Integer loginUserId;
	Student loginStudent;

	public FrmStudentScoreList(Integer loginUserId) {
		super("学生成绩管理", false, true, false, false);
		this.loginUserId = loginUserId;
		loginStudent = new StudentBll().mapUserIdStudent(loginUserId);
		InitializeComponent();
	}

	private void InitializeComponent() {
		// 1.窗口
		this.setDefaultCloseOperation(HIDE_ON_CLOSE);

		// 2.顶部
		JPanel paneHeader = new JPanel();
		// 标题
		JLabel lblTitle = new JLabel("课程成绩列表", JLabel.CENTER);
		paneHeader.add(lblTitle);
		this.getContentPane().add(paneHeader, BorderLayout.NORTH);
		// 3.分页控件
		JPanel panelPage = new JPanel(new GridLayout(1, 8));
		btnFirst = new JButton("<<首页");
		btnFirst.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				pageIndex = 1;
				refreshData();
			}
		});
		panelPage.add(btnFirst);
		btnPrev = new JButton("<上一页");
		btnPrev.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				pageIndex = pageIndex - 1;
				refreshData();
			}
		});
		panelPage.add(btnPrev);
		btnNext = new JButton("下一页>");
		btnNext.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				pageIndex = pageIndex + 1;
				refreshData();
			}
		});
		panelPage.add(btnNext);
		btnLast = new JButton("末页>>");
		btnLast.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				pageIndex = pageCount;
				refreshData();
			}
		});
		panelPage.add(btnLast);
		JButton btnSkip = new JButton("跳转到:");
		btnSkip.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					String s = txtPageIndex.getText();
					Integer i = Integer.parseInt(s);
					if (i >= 1 && i <= pageCount) {
						pageIndex = i;
						refreshData();
					} else {
						JOptionPane.showMessageDialog(null, String.format("拟跳转页码错误,值范围:%d-%d", 1, pageCount));
					}

				} catch (Exception ex) {
					JOptionPane.showMessageDialog(null, "输入页码必须是数字");
				}
			}
		});
		panelPage.add(btnSkip);
		txtPageIndex = new TextField();
		panelPage.add(txtPageIndex);
		JLabel lblPage = new JLabel("页");
		panelPage.add(lblPage);
		lblPageInfo = new JLabel();
		panelPage.add(lblPageInfo);
		this.getContentPane().add(panelPage, BorderLayout.SOUTH);
		// 4.列表
		table = new JTable();
		table.setRowHeight(30);// 设置行高
		refreshData();// 首次刷新
		// table添加到滚动面板
		JScrollPane sp = new JScrollPane(table);
		// 滚动面板添加到页面
		this.getContentPane().add(sp, BorderLayout.CENTER);
	}

	// 刷新数据
	private void refreshData() {
		// 刷新表格
		dtm = genTableModel();
		table.setModel(dtm);
		// 设置分页控件的状态
		btnFirst.setEnabled(true);
		btnPrev.setEnabled(true);
		btnNext.setEnabled(true);
		btnLast.setEnabled(true);
		if (pageIndex == 1) {
			btnFirst.setEnabled(false);
			btnPrev.setEnabled(false);
		}
		if (pageIndex == pageCount) {
			btnNext.setEnabled(false);
			btnLast.setEnabled(false);
		}
	}

	private DefaultTableModel genTableModel() {
		// 1.获取需要展示的数据
		StudentCourseBll studentCourseBll = new StudentCourseBll();
		List<StudentCourse> allStudentCourse = studentCourseBll.getListByStudentId(loginStudent.getId());
		// 2.确定pageCount与pageInfo
		int total = allStudentCourse.size();
		pageCount = total / pageSize;
		if (total % pageSize != 0) {
			pageCount = pageCount + 1;
		}
		int startRow = (pageIndex - 1) * pageSize + 1;
		int endRow = Math.min(total, pageIndex * pageSize);
		lblPageInfo.setText(String.format("共%d行,第%d行-%d行", total, startRow, endRow));
		// 3.当前页的数据
		List<StudentCourse> subList = allStudentCourse.stream().skip((pageIndex - 1) * pageSize).limit(pageSize)
				.collect(Collectors.toList());
		// 4.映射准备
		// 课程
		CourseBll courseBll = new CourseBll();
		List<Course> allCourse = new ArrayList<>();
		List<Integer> idRange = subList.stream().filter(x -> x.getCourseId() != null).map(StudentCourse::getCourseId)
				.distinct().collect(Collectors.toList());
		if (idRange.size() > 0) {
			allCourse = courseBll.getByIds(idRange);
		}
		// 教师
		TeacherBll teacherBll = new TeacherBll();
		List<Teacher> allTeacher = new ArrayList<>();
		idRange = subList.stream().filter(x -> x.getTeacherId() != null).map(StudentCourse::getTeacherId).distinct()
				.collect(Collectors.toList());
		if (idRange.size() > 0) {
			allTeacher = teacherBll.getByIds(idRange);
		}
		// 5.列头
		String[] arrColumnHeader = { "id", "学期", "课程", "教师", "成绩" };
		// 6.转换为表格所需格式
		Object[][] rowData = new Object[subList.size()][arrColumnHeader.length];
		int row = 0;
		for (StudentCourse mo : subList) {
			rowData[row][0] = mo.getId();
			rowData[row][1] = mo.getTerm();
			rowData[row][2] = courseBll.mapNameById(mo.getCourseId(), allCourse);
			rowData[row][3] = teacherBll.mapNameById(mo.getTeacherId(), allTeacher);
			rowData[row][4] = mo.getScore();
			row++;
		}
		// 7.返回值
		return new DefaultTableModel(rowData, arrColumnHeader) {
			public boolean isCellEditable(int row, int column) {
				return false;
			}
		};
	}
}
