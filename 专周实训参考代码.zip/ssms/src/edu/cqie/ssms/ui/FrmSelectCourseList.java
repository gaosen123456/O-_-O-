package edu.cqie.ssms.ui;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.GridLayout;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.swing.AbstractAction;
import javax.swing.AbstractCellEditor;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;

import edu.cqie.ssms.bll.CourseBll;
import edu.cqie.ssms.bll.StudentBll;
import edu.cqie.ssms.bll.StudentCourseBll;
import edu.cqie.ssms.bll.TeacherBll;
import edu.cqie.ssms.domain.Course;
import edu.cqie.ssms.domain.Student;
import edu.cqie.ssms.domain.StudentCourse;
import edu.cqie.ssms.domain.Teacher;

@SuppressWarnings("serial")
public class FrmSelectCourseList extends JInternalFrame {
	Integer loginUserId;
	Student loginStudent;
	JTable table = null;
	DefaultTableModel dtm = null;
	Boolean mustSaveFlag;

	JButton btnFirst;
	JButton btnPrev;
	JButton btnNext;
	JButton btnLast;
	TextField txtPageIndex;
	JLabel lblPageInfo;
	Integer pageIndex = 1;// 页号
	Integer pageSize = 19;// 每页记录数
	Integer pageCount = 0;// 总页数

	public FrmSelectCourseList(Integer loginUserId) {
		super("选课结果管理", false, true, false, false);
		this.loginUserId = loginUserId;
		loginStudent = new StudentBll().mapUserIdStudent(loginUserId);
		InitializeComponent();
	}

	// 初始化页面的部件
	private void InitializeComponent() {
		// 1.窗口
		this.setDefaultCloseOperation(HIDE_ON_CLOSE);

		// 2.顶部
		JPanel paneHeader = new JPanel(new GridLayout(0, 1));
		// 标题
		JLabel lblTitle = new JLabel("选课结果列表", JLabel.CENTER);
		paneHeader.add(lblTitle);
		// 新增按钮
		JButton btnAdd = new JButton("新增");
		btnAdd.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// 1.显示新增窗口
				FrmSelectCourseList main = FrmSelectCourseList.this;
				main.mustSaveFlag = false;
				FrmSelectCourseEdit dlg = new FrmSelectCourseEdit(main, 0, loginUserId);
				dlg.setDefaultCloseOperation(JDialog.HIDE_ON_CLOSE);
				dlg.setVisible(true);
				// 2.同步表格数据
				if (main.mustSaveFlag) {
					refreshData();
				}
			}
		});
		paneHeader.add(btnAdd);
		this.getContentPane().add(paneHeader, BorderLayout.NORTH);
		// 3.分页控件
		JPanel panelPage = new JPanel(new GridLayout(1, 8));
		btnFirst = new JButton("<<首页");
		btnFirst.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				pageIndex = 1;
				refreshData();
			}
		});
		panelPage.add(btnFirst);
		btnPrev = new JButton("<上一页");
		btnPrev.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				pageIndex = pageIndex - 1;
				refreshData();
			}
		});
		panelPage.add(btnPrev);
		btnNext = new JButton("下一页>");
		btnNext.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				pageIndex = pageIndex + 1;
				refreshData();
			}
		});
		panelPage.add(btnNext);
		btnLast = new JButton("末页>>");
		btnLast.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				pageIndex = pageCount;
				refreshData();
			}
		});
		panelPage.add(btnLast);
		JButton btnSkip = new JButton("跳转到:");
		btnSkip.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					String s = txtPageIndex.getText();
					Integer i = Integer.parseInt(s);
					if (i >= 1 && i <= pageCount) {
						pageIndex = i;
						refreshData();
					} else {
						JOptionPane.showMessageDialog(null, String.format("拟跳转页码错误,值范围:%d-%d", 1, pageCount));
					}

				} catch (Exception ex) {
					JOptionPane.showMessageDialog(null, "输入页码必须是数字");
				}
			}
		});
		panelPage.add(btnSkip);
		txtPageIndex = new TextField();
		panelPage.add(txtPageIndex);
		JLabel lblPage = new JLabel("页");
		panelPage.add(lblPage);
		lblPageInfo = new JLabel("共X行,第x行-第x行");
		panelPage.add(lblPageInfo);
		this.getContentPane().add(panelPage, BorderLayout.SOUTH);
		// 4.列表
		table = new JTable();
		table.setRowHeight(30);// 设置行高
		refreshData();// 首次刷新
		// table添加到滚动面板
		JScrollPane sp = new JScrollPane(table);
		// 滚动面板添加到页面
		this.getContentPane().add(sp, BorderLayout.CENTER);
	}

	// 生成表格的Model
	private DefaultTableModel genTableModel() {
		// 1.获取需展示数据
		// 1.1访问数据库
		StudentCourseBll studentCourseBll = new StudentCourseBll();
		List<StudentCourse> allStudentCourse = studentCourseBll.getAll();
		// 1.2确定pageCount及pageInfo
		int total = allStudentCourse.size();// 总记录数
		// 总页数
		pageCount = total / pageSize;
		if (total % pageSize != 0) {
			pageCount = pageCount + 1;
		}
		// 当前页
		int startRow = (pageIndex - 1) * pageSize + 1;// 当前页开始行号
		int endRow = Math.min(total, pageIndex * pageSize);// 当前页结束行号
		lblPageInfo.setText(String.format("共%d行,第%d行-%d行", total, startRow, endRow));
		// 1.3当前页的数据
		List<StudentCourse> subList = allStudentCourse.stream().skip((pageIndex - 1) * pageSize).limit(pageSize)
				.collect(Collectors.toList());
		// 1.4映射准备
		// 学生
		List<Student> allStudent = new ArrayList<>();
		StudentBll studentBll = new StudentBll();
		List<Integer> idRange = subList.stream().filter(x -> x.getStudentId() != null).map(StudentCourse::getStudentId)
				.distinct().collect(Collectors.toList());
		if (idRange.size() > 0) {
			allStudent = studentBll.getByIds(idRange);
		}
		// 课程
		List<Course> allCourse = new ArrayList<>();
		CourseBll courseBll = new CourseBll();
		idRange = subList.stream().filter(x -> x.getCourseId() != null).map(StudentCourse::getCourseId).distinct()
				.collect(Collectors.toList());
		if (idRange.size() > 0) {
			allCourse = courseBll.getByIds(idRange);
		}
		// 教师
		List<Teacher> allTeacher = new ArrayList<>();
		TeacherBll teacherBll = new TeacherBll();
		idRange = subList.stream().filter(x -> x.getTeacherId() != null).map(StudentCourse::getTeacherId).distinct()
				.collect(Collectors.toList());
		if (idRange.size() > 0) {
			allTeacher = teacherBll.getByIds(idRange);
		}
		// 2.列头
		String[] arrColumnHeader = { "id", "学生", "课程", "教师", "学期", "操作" };
		// 3.转换为表格所需格式
		Object[][] rowData = new Object[subList.size()][arrColumnHeader.length];
		int row = 0;
		for (StudentCourse mo : subList) {
			rowData[row][0] = mo.getId();
			rowData[row][1] = studentBll.mapNameById(mo.getStudentId(), allStudent);
			rowData[row][2] = courseBll.mapNameById(mo.getCourseId(), allCourse);
			rowData[row][3] = teacherBll.mapNameById(mo.getTeacherId(), allTeacher);
			rowData[row][4] = mo.getTerm();
			row++;
		}
		// 4.返回值
		DefaultTableModel dtm = new DefaultTableModel(rowData, arrColumnHeader) {
			public boolean isCellEditable(int row, int column) {
				return column == (arrColumnHeader.length - 1)
						&& rowData[row][1].toString().equals(loginStudent.getName());
			}
		};
		return dtm;
	}

	// 行操作所在单元格的渲染器
	private class MyRenderer extends JComponent implements TableCellRenderer {
		TableCellEditor editor;

		public MyRenderer(TableCellEditor editor) {
			this.editor = editor;
		}

		@Override
		public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus,
				int row, int column) {
			return editor.getTableCellEditorComponent(table, value, isSelected, row, column);
		}
	}

	// 行操作所在单元格的编辑器
	private class MyEditor extends AbstractCellEditor implements TableCellEditor {
		int row;
		JTable table;
		JPanel panel;

		public MyEditor() {
			panel = new JPanel();
			panel.setLayout(new GridLayout(1, 2));
			JButton btnEdit = new JButton("编辑");
			btnEdit.addActionListener(new AbstractAction() {
				@Override
				public void actionPerformed(ActionEvent e) {
					Integer id = (Integer) table.getValueAt(row, 0);
					System.out.println("准备编辑id=" + id + "的班级");
					// 1.显示编辑窗口
					FrmSelectCourseList main = FrmSelectCourseList.this;
					main.mustSaveFlag = false;
					FrmSelectCourseEdit dlg = new FrmSelectCourseEdit(main, id, loginUserId);
					dlg.setDefaultCloseOperation(JDialog.HIDE_ON_CLOSE);
					dlg.setVisible(true);
					// 2.同步表格数据
					if (main.mustSaveFlag) {
						refreshData();
					}
				}
			});
			panel.add(btnEdit);
			JButton btnDelete = new JButton("删除");
			btnDelete.addActionListener(new AbstractAction() {
				@Override
				public void actionPerformed(ActionEvent e) {
					Integer id = (Integer) table.getValueAt(row, 0);
					System.out.println("准备删除id=" + id + "的班级");
					// 用户确认删除操作的执行
					int isDelete = JOptionPane.showConfirmDialog(null, "确定删除", "提示", JOptionPane.YES_NO_OPTION);
					if (isDelete == JOptionPane.YES_OPTION) {
						// 1.执行删除
						StudentCourseBll studentCourseBll = new StudentCourseBll();
						studentCourseBll.remove(id);
						// 2.同步表格数据
						refreshData();
						// 3.删除成功提示
						JOptionPane.showMessageDialog(null, "删除成功");
					}
				}
			});
			panel.add(btnDelete);
		}

		@Override
		public Object getCellEditorValue() {
			return null;
		}

		@Override
		public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row,
				int column) {
			this.table = table;
			this.row = row;
			return panel;
		}
	}

	// 刷新数据
	private void refreshData() {
		// 刷新数据
		dtm = genTableModel();
		table.setModel(dtm);
		table.getColumn("操作").setCellRenderer(new MyRenderer(new MyEditor()));
		table.getColumn("操作").setCellEditor(new MyEditor());
		// 控制分页按钮状态
		btnFirst.setEnabled(true);
		btnPrev.setEnabled(true);
		btnNext.setEnabled(true);
		btnLast.setEnabled(true);
		if (pageIndex == 1) {
			btnFirst.setEnabled(false);
			btnPrev.setEnabled(false);
		}
		if (pageIndex == pageCount) {
			btnNext.setEnabled(false);
			btnLast.setEnabled(false);
		}
	}
}
